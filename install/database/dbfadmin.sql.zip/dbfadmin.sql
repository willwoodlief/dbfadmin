-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 08, 2016 at 02:52 AM
-- Server version: 5.5.52-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbfadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_email`
--

CREATE TABLE IF NOT EXISTS `app_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(100) NOT NULL,
  `smtp_server` varchar(100) NOT NULL,
  `smtp_port` int(10) NOT NULL,
  `email_login` varchar(150) NOT NULL,
  `email_pass` varchar(100) NOT NULL,
  `from_name` varchar(100) NOT NULL,
  `from_email` varchar(150) NOT NULL,
  `transport` varchar(255) NOT NULL,
  `verify_url` varchar(255) NOT NULL,
  `email_act` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `app_email`
--

INSERT INTO `app_email` (`id`, `website_name`, `smtp_server`, `smtp_port`, `email_login`, `email_pass`, `from_name`, `from_email`, `transport`, `verify_url`, `email_act`) VALUES
(1, 'emailsrvr.com', 'smtp.emailsrvr.com', 587, 'info@gokabam.com', 'apple-daily-8', 'DBF App', 'info@gokabam.com', 'tls', 'http://localhost/dbfadmin/', 0);

-- --------------------------------------------------------

--
-- Table structure for table `app_keys`
--

CREATE TABLE IF NOT EXISTS `app_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stripe_ts` varchar(255) NOT NULL,
  `stripe_tp` varchar(255) NOT NULL,
  `stripe_ls` varchar(255) NOT NULL,
  `stripe_lp` varchar(255) NOT NULL,
  `recap_pub` varchar(100) NOT NULL,
  `recap_pri` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `app_pages`
--

CREATE TABLE IF NOT EXISTS `app_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(100) NOT NULL,
  `private` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `app_pages`
--

INSERT INTO `app_pages` (`id`, `page`, `private`) VALUES
(1, 'index.php', 0),
(2, 'z_us_root.php', 0),
(3, 'users/account.php', 1),
(4, 'users/admin.php', 1),
(5, 'users/admin_page.php', 1),
(6, 'users/admin_pages.php', 1),
(7, 'users/admin_permission.php', 1),
(8, 'users/admin_permissions.php', 1),
(9, 'users/admin_user.php', 1),
(10, 'users/admin_users.php', 1),
(11, 'users/edit_profile.php', 1),
(12, 'users/email_settings.php', 1),
(13, 'users/email_test.php', 1),
(14, 'users/forgot_password.php', 0),
(15, 'users/forgot_password_reset.php', 0),
(16, 'users/index.php', 0),
(17, 'users/init.php', 0),
(18, 'users/join.php', 0),
(19, 'users/joinThankYou.php', 0),
(20, 'users/login.php', 0),
(21, 'users/logout.php', 0),
(22, 'users/profile.php', 1),
(23, 'users/times.php', 0),
(24, 'users/user_settings.php', 1),
(25, 'users/verify.php', 0),
(26, 'users/verify_resend.php', 0),
(27, 'users/view_all_users.php', 1),
(28, 'usersc/empty.php', 0),
(29, 'info.php', 0),
(30, 'users/private_init.example.php', 0),
(31, 'users/private_init.php', 0),
(33, 'pages/index.php', 0),
(34, 'pages/status.php', 1),
(35, 'pages/mappings.php', 1),
(37, 'pages/upload.php', 1),
(38, 'pages/validate.php', 1),
(42, 'pages/ajax_aliases.php', 1),
(43, 'pages/alias_column_grid.php', 1),
(44, 'pages/last_property_dump.php', 1),
(45, 'pages/upload_history.php', 1),
(46, 'pages/ajax_templates.php', 1),
(47, 'pages/template_grid.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `app_permissions`
--

CREATE TABLE IF NOT EXISTS `app_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `app_permissions`
--

INSERT INTO `app_permissions` (`id`, `name`) VALUES
(1, 'User'),
(2, 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `app_permission_page_matches`
--

CREATE TABLE IF NOT EXISTS `app_permission_page_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(15) NOT NULL,
  `page_id` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `app_permission_page_matches`
--

INSERT INTO `app_permission_page_matches` (`id`, `permission_id`, `page_id`) VALUES
(2, 2, 27),
(3, 1, 24),
(4, 1, 22),
(5, 2, 13),
(6, 2, 12),
(7, 1, 11),
(8, 2, 10),
(9, 2, 9),
(10, 2, 8),
(11, 2, 7),
(12, 2, 6),
(13, 2, 5),
(14, 2, 4),
(15, 1, 3),
(16, 1, 34),
(17, 2, 34),
(18, 2, 35),
(19, 2, 36),
(20, 1, 37),
(21, 2, 37),
(22, 1, 38),
(23, 2, 38),
(24, 2, 39),
(25, 2, 40),
(26, 2, 41),
(27, 2, 42),
(28, 2, 43),
(29, 1, 44),
(30, 2, 44),
(31, 1, 45),
(32, 2, 45),
(33, 2, 47),
(34, 2, 46);

-- --------------------------------------------------------

--
-- Table structure for table `app_profiles`
--

CREATE TABLE IF NOT EXISTS `app_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bio` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `app_profiles`
--

INSERT INTO `app_profiles` (`id`, `user_id`, `bio`) VALUES
(1, 1, '<h1>This is the Admin''s bio.</h1>'),
(2, 2, 'This is your bio'),
(18, 18, 'This is your bio');

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE IF NOT EXISTS `app_settings` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `recaptcha` int(1) NOT NULL DEFAULT '0',
  `force_ssl` int(1) NOT NULL,
  `login_type` varchar(20) NOT NULL,
  `css_sample` int(1) NOT NULL,
  `us_css1` varchar(255) NOT NULL,
  `us_css2` varchar(255) NOT NULL,
  `us_css3` varchar(255) NOT NULL,
  `css1` varchar(255) NOT NULL,
  `css2` varchar(255) NOT NULL,
  `css3` varchar(255) NOT NULL,
  `site_name` varchar(100) NOT NULL,
  `language` varchar(255) NOT NULL,
  `track_guest` int(1) NOT NULL,
  `site_offline` int(1) NOT NULL,
  `force_pr` int(1) NOT NULL,
  `reserved1` varchar(100) NOT NULL,
  `reserverd2` varchar(100) NOT NULL,
  `custom1` varchar(100) NOT NULL,
  `custom2` varchar(100) NOT NULL,
  `custom3` varchar(100) NOT NULL,
  `wx_template_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wx_template_id` (`wx_template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `app_settings`
--

INSERT INTO `app_settings` (`id`, `recaptcha`, `force_ssl`, `login_type`, `css_sample`, `us_css1`, `us_css2`, `us_css3`, `css1`, `css2`, `css3`, `site_name`, `language`, `track_guest`, `site_offline`, `force_pr`, `reserved1`, `reserverd2`, `custom1`, `custom2`, `custom3`, `wx_template_id`) VALUES
(1, 1, 0, '', 1, '../users/css/color_schemes/standard.css', '../users/css/sb-admin.css', '../users/css/custom.css', '', '', '', 'DBF Imports', 'en', 0, 0, 0, '', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `app_users`
--

CREATE TABLE IF NOT EXISTS `app_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(155) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `permissions` int(11) NOT NULL,
  `logins` int(100) NOT NULL,
  `account_owner` tinyint(4) NOT NULL DEFAULT '0',
  `account_id` int(11) NOT NULL DEFAULT '0',
  `company` varchar(255) NOT NULL,
  `stripe_cust_id` varchar(255) NOT NULL,
  `billing_phone` varchar(20) NOT NULL,
  `billing_srt1` varchar(255) NOT NULL,
  `billing_srt2` varchar(255) NOT NULL,
  `billing_city` varchar(255) NOT NULL,
  `billing_state` varchar(255) NOT NULL,
  `billing_zip_code` varchar(255) NOT NULL,
  `join_date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `email_verified` tinyint(4) NOT NULL DEFAULT '0',
  `vericode` varchar(15) NOT NULL,
  `title` varchar(100) NOT NULL,
  `active` int(1) NOT NULL,
  `custom1` varchar(255) NOT NULL,
  `custom2` varchar(255) NOT NULL,
  `custom3` varchar(255) NOT NULL,
  `custom4` varchar(255) NOT NULL,
  `custom5` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `EMAIL` (`email`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `app_users`
--

INSERT INTO `app_users` (`id`, `email`, `username`, `password`, `fname`, `lname`, `permissions`, `logins`, `account_owner`, `account_id`, `company`, `stripe_cust_id`, `billing_phone`, `billing_srt1`, `billing_srt2`, `billing_city`, `billing_state`, `billing_zip_code`, `join_date`, `last_login`, `email_verified`, `vericode`, `title`, `active`, `custom1`, `custom2`, `custom3`, `custom4`, `custom5`) VALUES
(1, 'userspicephp@gmail.com', 'admin', '$2y$12$9R4u4lVraHZeJJ6YVJxO4e43./LZQLwC3VVlS1BvSN1IsZJDOooFK', 'Admin', 'User', 1, 7, 1, 0, 'UserSpice', '', '', '', '', '', '', '', '2016-01-01 00:00:00', '2016-10-08 00:16:07', 1, '322418', '', 0, '', '', '', '', ''),
(2, 'noreply@userspice.com', 'user', '$2y$12$HZa0/d7evKvuHO8I3U8Ff.pOjJqsGTZqlX8qURratzP./EvWetbkK', 'user', 'user', 1, 0, 1, 0, 'none', '', '', '', '', '', '', '', '2016-01-02 00:00:00', '2016-01-02 00:00:00', 1, '970748', '', 1, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `app_users_online`
--

CREATE TABLE IF NOT EXISTS `app_users_online` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `timestamp` varchar(15) NOT NULL,
  `user_id` int(10) NOT NULL,
  `session` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `app_users_session`
--

CREATE TABLE IF NOT EXISTS `app_users_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `uagent` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `app_users_session`
--

INSERT INTO `app_users_session` (`id`, `user_id`, `hash`, `uagent`) VALUES
(38, 1, 'e5c284103ce354831561e3b447d1758976c799922d7e20743e9f8c290dfe078f', 'Mozilla (Windows NT 6.1; Win64; x64) AppleWebKit (KHTML, like Gecko) Chrome Safari'),
(39, 1, '6523a6faed7f03a1a7e96173a332d64da4cd477dd8997c7e36967eb81d2ed253', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:48.0) Gecko Firefox'),
(40, 1, 'd9d630707a976b27d5b7edfe8d99f75e611ff07c46c91d238d047301cb817a59', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox'),
(41, 1, 'f1e80d8c93a54f882d6235609d86b3e4e353554126b02d10a7dca3b15b97faf9', 'Mozilla (X11; Linux x86_64) AppleWebKit (KHTML, like Gecko) Chrome Safari'),
(42, 1, '150f42fc139b188dba7fc9b2f9e22011d08a7aeee7e347b5ccd446a32264df28', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox');

-- --------------------------------------------------------

--
-- Table structure for table `app_user_permission_matches`
--

CREATE TABLE IF NOT EXISTS `app_user_permission_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `app_user_permission_matches`
--

INSERT INTO `app_user_permission_matches` (`id`, `user_id`, `permission_id`) VALUES
(100, 1, 1),
(101, 1, 2),
(102, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contractor`
--

CREATE TABLE IF NOT EXISTS `contractor` (
  `ContractorId` int(12) NOT NULL AUTO_INCREMENT,
  `ContractorName` varchar(120) NOT NULL,
  `ContractorAddress` varchar(200) DEFAULT NULL,
  `ContractorPhone` varchar(50) DEFAULT NULL,
  `ContractorType` varchar(1) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`ContractorId`),
  KEY `fk_Contractor_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `homebuilder`
--

CREATE TABLE IF NOT EXISTS `homebuilder` (
  `HomeBuilderId` int(12) NOT NULL AUTO_INCREMENT,
  `HomeBuilderName` varchar(80) NOT NULL,
  `HomeBuilderAddress` varchar(120) DEFAULT NULL,
  `HomeBuilderPhone` varchar(50) DEFAULT NULL,
  `LogoAddress` varchar(120) DEFAULT NULL,
  `WebsiteAddress` varchar(120) DEFAULT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`HomeBuilderId`),
  KEY `fk_HomeBuilder_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `parking`
--

CREATE TABLE IF NOT EXISTS `parking` (
  `ParkingId` int(12) NOT NULL AUTO_INCREMENT,
  `ParkingType` varchar(2) NOT NULL,
  `ParkingQty` int(2) NOT NULL,
  `ParkingDescription` varchar(120) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`ParkingId`),
  KEY `fk_Parking_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_Parking_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pricecomparison`
--

CREATE TABLE IF NOT EXISTS `pricecomparison` (
  `PriceComparisonId` int(12) NOT NULL AUTO_INCREMENT,
  `PriceComparisonDescription` varchar(80) DEFAULT NULL,
  `PriceComparisonBarCode` varchar(50) DEFAULT NULL,
  `PriceComparisonCompany` varchar(80) DEFAULT NULL,
  `PriceComparisonAddress` varchar(120) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PriceComparisonId`),
  KEY `fk_PriceComparison_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyactivity`
--

CREATE TABLE IF NOT EXISTS `propertyactivity` (
  `PropertyActivityId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyActivityDate` date NOT NULL,
  `ContractorId` int(12) NOT NULL,
  `PropertyActivityDescription` varchar(200) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyActivityId`),
  KEY `fk_PropertyActivity_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyActivity_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyconstruction`
--

CREATE TABLE IF NOT EXISTS `propertyconstruction` (
  `PropertyConstructionId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyConstructionDescription` varchar(120) NOT NULL,
  `PropertyConstructionDate` date NOT NULL,
  `PropertyConstructionFloor` int(2) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyConstructionId`),
  KEY `fk_PropertyConstruction_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyConstruction_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertydeed`
--

CREATE TABLE IF NOT EXISTS `propertydeed` (
  `PropertyDeedId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyDeedDate` date NOT NULL,
  `PropertyDeedNumber` varchar(50) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyDeedId`),
  KEY `fk_PropertyDeed_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyDeed_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertydocuments`
--

CREATE TABLE IF NOT EXISTS `propertydocuments` (
  `PropertyDocumentId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyDocumentType` varchar(2) NOT NULL,
  `PropertyDocumentDate` date NOT NULL,
  `PropertyDocumentAddress` varchar(200) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyDocumentId`),
  KEY `fk_PropertyDocuments_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyDocuments_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertygf`
--

CREATE TABLE IF NOT EXISTS `propertygf` (
  `PropertyGFId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyGFNumber` varchar(50) NOT NULL,
  `PropertyGFDate` date NOT NULL,
  `PropertyGFDescription` varchar(120) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyGFId`),
  KEY `fk_PropertyGF_PropertyMain_idx` (`PropertyId`),
  KEY `fk_PropertyGF_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyitem`
--

CREATE TABLE IF NOT EXISTS `propertyitem` (
  `PropertyItemId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyItemName` varchar(120) NOT NULL,
  `PropertyItemStorePurchased` varchar(120) DEFAULT NULL,
  `PropertyItemBarcode` varchar(50) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyItemId`),
  KEY `fk_PropertyItem_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyiteminstallation`
--

CREATE TABLE IF NOT EXISTS `propertyiteminstallation` (
  `PropertyItemInstallationId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyItemInstallationDate` date NOT NULL,
  `PropertyItemId` int(12) NOT NULL,
  `AnyDescription` varchar(120) DEFAULT NULL,
  `PropertyContractorId` int(12) NOT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Brand` varchar(50) DEFAULT NULL,
  `FinishType` varchar(50) DEFAULT NULL,
  `Manufacturer` varchar(80) DEFAULT NULL,
  `Model` varchar(50) DEFAULT NULL,
  `Qty` int(5) DEFAULT NULL,
  `DateInstalled` date NOT NULL,
  `Warranty` int(3) DEFAULT NULL,
  `PropertyConstructionId` int(12) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyItemInstallationId`),
  KEY `fk_PropertyItemInstallation_Contractor1_idx` (`PropertyContractorId`),
  KEY `fk_PropertyItemInstallation_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyItemInstallation_PropertyConstruction1_idx` (`PropertyConstructionId`),
  KEY `fk_PropertyItemInstallation_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyiteminstallation_has_propertyitem`
--

CREATE TABLE IF NOT EXISTS `propertyiteminstallation_has_propertyitem` (
  `PropertyItemInstallation_PropertyItemInstallationId` int(12) NOT NULL,
  `PropertyItem_PropertyItemId` int(12) NOT NULL,
  PRIMARY KEY (`PropertyItemInstallation_PropertyItemInstallationId`,`PropertyItem_PropertyItemId`),
  KEY `fk_PropertyItemInstallation_has_PropertyItem_PropertyItem1_idx` (`PropertyItem_PropertyItemId`),
  KEY `fk_PropertyItemInstallation_has_PropertyItem_PropertyItemIn_idx` (`PropertyItemInstallation_PropertyItemInstallationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `propertymain`
--

CREATE TABLE IF NOT EXISTS `propertymain` (
  `PropertyId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyType` varchar(1) DEFAULT NULL,
  `PropertySubType` varchar(30) DEFAULT NULL,
  `PropertyOwnNumber` varchar(10) DEFAULT NULL,
  `PropertyCountry` varchar(50) DEFAULT NULL,
  `PropertyZipCode` varchar(50) DEFAULT NULL,
  `PropertyState` varchar(50) DEFAULT NULL,
  `PropertyCounty` varchar(50) DEFAULT NULL,
  `PropertyCity` varchar(120) DEFAULT NULL,
  `PropertyNeighborhood` varchar(255) DEFAULT NULL,
  `PropertyStreetNumber` varchar(255) DEFAULT NULL,
  `PropertyStreetName` varchar(255) DEFAULT NULL,
  `PropertyStreetDirectionSuffix` varchar(255) DEFAULT NULL,
  `PropertyStreetType` varchar(255) DEFAULT NULL,
  `PropertyBlock` varchar(25) DEFAULT NULL,
  `PropertyLot` varchar(30) DEFAULT NULL,
  `PropertySubDivision` varchar(50) DEFAULT NULL,
  `PropertyParcelNumber` varchar(255) DEFAULT NULL,
  `PropertySubType2` varchar(255) DEFAULT NULL,
  `PropertyParcelZoning` varchar(255) DEFAULT NULL,
  `PropertyParcelUse` varchar(255) DEFAULT NULL,
  `PropertyAcres` varchar(255) DEFAULT NULL,
  `PropertyBuildingStyle` varchar(255) DEFAULT NULL,
  `PropertyNumberOfUnits` varchar(255) DEFAULT NULL,
  `PropertyLegalDescription` varchar(300) DEFAULT NULL,
  `PropertyLegal2` varchar(255) DEFAULT NULL,
  `PropertyLegal3` varchar(255) DEFAULT NULL,
  `PropertyTaxNumber` varchar(80) DEFAULT NULL,
  `PropertyBuiltYear` int(4) DEFAULT NULL,
  `PropertyBuilderId` int(12) DEFAULT NULL,
  `PropertyNumberOfRoom` int(4) DEFAULT NULL,
  `PropertyNumberOfBath` int(4) DEFAULT NULL,
  `PropertyNumberOfStory` int(4) DEFAULT NULL,
  `PropertyLandSQFT` decimal(15,4) DEFAULT NULL,
  `PropertyLivingArea` int(4) DEFAULT NULL,
  `PropertyGarage` varchar(1) DEFAULT NULL,
  `PropertyCoveredPatio` varchar(1) DEFAULT NULL,
  `PropertyOpenPatio` varchar(1) DEFAULT NULL,
  `PropertyWaterSource` varchar(50) DEFAULT NULL,
  `PropertySewerSource` varchar(50) DEFAULT NULL,
  `PropertyHasGas` varchar(30) DEFAULT NULL,
  `PropertyPropane` varchar(1) DEFAULT NULL,
  `PropertyElectricitySource` varchar(50) DEFAULT NULL,
  `PropertylongLocation` decimal(18,14) DEFAULT NULL,
  `PropertyLatLocation` decimal(18,14) DEFAULT NULL,
  `PropertyGeographicCodeX` varchar(255) DEFAULT NULL,
  `PropertyGeographicCodeY` varchar(255) DEFAULT NULL,
  `PropertyConstructionType` varchar(2) DEFAULT NULL,
  `PropertyFoundationType` varchar(2) DEFAULT NULL,
  `PropertySwimming` int(1) DEFAULT NULL,
  `PropertyPictures` varchar(255) DEFAULT NULL,
  `PropertyNewHomeSelectionSheet` varchar(255) DEFAULT NULL,
  `PropertyLinkTaxAssessorData` varchar(255) DEFAULT NULL,
  `EntryDate` date DEFAULT NULL,
  `UserId` int(9) DEFAULT NULL,
  PRIMARY KEY (`PropertyId`),
  KEY `fk_PropertyMain_HomeBuilder1_idx` (`PropertyBuilderId`),
  KEY `fk_PropertyMain_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertypaint`
--

CREATE TABLE IF NOT EXISTS `propertypaint` (
  `PropertyPaintId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyPaintDate` date NOT NULL,
  `PropertyItemPaintFor` varchar(80) NOT NULL,
  `PropertyPaintBrand` varchar(50) DEFAULT NULL,
  `PropertyPaintColor` varchar(50) DEFAULT NULL,
  `PropertyPaintFinishType` varchar(2) DEFAULT NULL,
  `Manufacturer` varchar(80) DEFAULT NULL,
  `PropertyPaintDateInstalled` date DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `PropertyConstructionId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyPaintId`),
  KEY `fk_PropertyPaint_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyPaint_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertypermit`
--

CREATE TABLE IF NOT EXISTS `propertypermit` (
  `PropertyPermitId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyPermitNumber` varchar(50) NOT NULL,
  `PropertyPermitDate` date NOT NULL,
  `PropertyPermitDescription` varchar(120) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyPermitId`),
  KEY `fk_PropertyPermit_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `storage`
--

CREATE TABLE IF NOT EXISTS `storage` (
  `StorageId` int(12) NOT NULL,
  `StorageType` varchar(1) NOT NULL,
  `StorageQty` int(2) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`StorageId`),
  KEY `fk_Storage_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_Storage_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `swimmingpool`
--

CREATE TABLE IF NOT EXISTS `swimmingpool` (
  `SwimmingPool_Id` int(12) NOT NULL AUTO_INCREMENT,
  `SwimmingPoolType` varchar(1) NOT NULL,
  `SwimmingPoolQty` int(2) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`SwimmingPool_Id`),
  KEY `fk_SwimmingPool_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_SwimmingPool_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uscity`
--

CREATE TABLE IF NOT EXISTS `uscity` (
  `USCityId` int(11) NOT NULL AUTO_INCREMENT,
  `USCityName` varchar(120) NOT NULL,
  `CountyId` int(6) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`USCityId`),
  KEY `fk_USCity_USCounty1_idx` (`CountyId`),
  KEY `fk_USCity_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uscounty`
--

CREATE TABLE IF NOT EXISTS `uscounty` (
  `USCountyId` int(6) NOT NULL AUTO_INCREMENT,
  `USCountyName` varchar(80) NOT NULL,
  `StateId` int(3) DEFAULT NULL,
  `EntryDate` date DEFAULT NULL,
  `UserId` int(9) DEFAULT NULL,
  PRIMARY KEY (`USCountyId`),
  KEY `fk_USCounty_UState1_idx` (`StateId`),
  KEY `fk_USCounty_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `UserId` int(9) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(80) NOT NULL,
  `UserPassword` varchar(30) NOT NULL,
  `DateCreated` date NOT NULL,
  `UserStateCode` varchar(2) NOT NULL,
  `UserType` varchar(3) NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ustate`
--

CREATE TABLE IF NOT EXISTS `ustate` (
  `UStateId` int(3) NOT NULL AUTO_INCREMENT,
  `UStateName` varchar(50) NOT NULL,
  `UStateCode` varchar(2) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`UStateId`),
  KEY `fk_UState_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE IF NOT EXISTS `wishlist` (
  `WishListId` int(12) NOT NULL AUTO_INCREMENT,
  `WishListDescription` varchar(80) DEFAULT NULL,
  `WishListBarCode` varchar(50) DEFAULT NULL,
  `WishListCompany` varchar(80) DEFAULT NULL,
  `WishListCompanyAddress` varchar(120) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`WishListId`),
  KEY `fk_WishList_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wx_batch`
--

CREATE TABLE IF NOT EXISTS `wx_batch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `app_user_id` (`app_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wx_batch_updates`
--

CREATE TABLE IF NOT EXISTS `wx_batch_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `name_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name_column` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_batch_updates_unique_entry` (`batch_id`,`name_table`,`name_column`),
  KEY `batch_id` (`batch_id`),
  KEY `idx_batch_update_tables` (`name_table`),
  KEY `idx_batch_update_column` (`name_column`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wx_templates`
--

CREATE TABLE IF NOT EXISTS `wx_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ts_created_at` int(11) NOT NULL,
  `ts_modified_at` int(11) DEFAULT NULL,
  `created_by_user_id` int(11) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_user_id` (`created_by_user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='This table is for keeping track of the different templates' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `wx_templates`
--

INSERT INTO `wx_templates` (`id`, `name`, `ts_created_at`, `ts_modified_at`, `created_by_user_id`, `notes`) VALUES
(1, 'Single House Property', 1475907853, 1475908041, 1, 'The template that handles the data from the sample single house sheets'),
(5, 'Sample Second Template', 1475908074, 1475908093, 1, 'Sample');

-- --------------------------------------------------------

--
-- Table structure for table `wx_template_columns`
--

CREATE TABLE IF NOT EXISTS `wx_template_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wx_template_id` int(11) DEFAULT NULL,
  `name_regex_alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_table` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_column` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flag_to_raise` int(11) DEFAULT NULL,
  `flag_needed_a` int(11) DEFAULT NULL,
  `flag_needed_b` int(11) DEFAULT NULL,
  `is_ignored` int(11) NOT NULL DEFAULT '0',
  `rank` float NOT NULL DEFAULT '0',
  `app_user_id` int(11) NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `name_regex_alias` (`name_regex_alias`),
  KEY `app_user_id` (`app_user_id`),
  KEY `rank` (`rank`),
  KEY `template_id_in_columns` (`wx_template_id`),
  KEY `flag_to_raise` (`flag_to_raise`),
  KEY `flag_needed_b` (`flag_needed_b`),
  KEY `flag_needed_a` (`flag_needed_a`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=59 ;

--
-- Dumping data for table `wx_template_columns`
--

INSERT INTO `wx_template_columns` (`id`, `wx_template_id`, `name_regex_alias`, `name_table`, `name_column`, `flag_to_raise`, `flag_needed_a`, `flag_needed_b`, `is_ignored`, `rank`, `app_user_id`, `modified_at`) VALUES
(3, 1, 'Data Entry Person', 'propertymain', 'PropertyOwnNumber', 1, NULL, NULL, 1, 1, 1, '2016-09-23 22:03:55'),
(4, 1, 'Property Identifier', 'propertymain', 'PropertyOwnNumber', NULL, NULL, NULL, 0, 2, 1, '2016-09-30 03:34:48'),
(5, 1, 'Property Type', 'propertymain', 'PropertyType', NULL, NULL, NULL, 0, 4, 1, '2016-09-30 03:39:28'),
(6, 1, 'Property Sub-type', 'propertymain', 'PropertySubType', NULL, NULL, NULL, 0, 4.5, 1, '2016-09-30 03:40:14'),
(7, 1, 'Property Street Address', 'propertymain', 'PropertyStreetName', NULL, NULL, NULL, 0, 5, 1, '2016-09-30 03:40:49'),
(8, 1, 'City', 'propertymain', 'PropertyCity', NULL, NULL, NULL, 0, 6, 1, '2016-09-30 03:43:28'),
(9, 1, 'State', 'propertymain', 'PropertyState', NULL, NULL, NULL, 0, 7, 1, '2016-09-30 03:43:29'),
(10, 1, 'Zip', 'propertymain', 'PropertyZipCode', NULL, NULL, NULL, 0, 8, 1, '2016-09-30 03:43:29'),
(11, 1, 'County', 'propertymain', 'PropertyCounty', NULL, NULL, NULL, 0, 9, 1, '2016-09-30 03:43:30'),
(12, 1, 'Country', 'propertymain', 'PropertyCountry', NULL, NULL, NULL, 0, 10, 1, '2016-09-30 03:44:19'),
(13, 1, 'Subdivision', 'propertymain', 'PropertySubDivision', NULL, NULL, NULL, 0, 11, 1, '2016-09-30 03:45:27'),
(14, 1, 'Legal Description', 'propertymain', 'PropertyLegalDescription', NULL, NULL, NULL, 0, 12, 1, '2016-09-30 03:45:28'),
(15, 1, 'GF Number', 'propertygf', 'PropertyGFNumber', NULL, NULL, NULL, 0, 13, 1, '2016-09-30 03:45:28'),
(16, 1, 'Tax ID', 'propertymain', 'PropertyTaxNumber', NULL, NULL, NULL, 0, 3, 1, '2016-09-30 03:45:29'),
(17, 1, 'Geographical Coordinates', 'propertymain', 'PropertyGeographicCodeX', NULL, NULL, NULL, 1, 14, 1, '2016-09-30 03:45:29'),
(18, 1, 'Date of Deed - Transfer', 'propertydeed', 'PropertyDeedDate', NULL, NULL, NULL, 0, 15, 1, '2016-09-30 03:45:29'),
(19, 1, 'Floor Plan', 'propertymain', '', NULL, NULL, NULL, 1, 16, 1, '2016-09-30 03:45:29'),
(20, 1, 'Date Built', 'propertymain', 'PropertyBuiltYear', NULL, NULL, NULL, 0, 17, 1, '2016-09-30 03:45:30'),
(21, 1, 'Type of Construction', 'propertymain', 'PropertyConstructionType', NULL, NULL, NULL, 0, 18, 1, '2016-09-30 03:45:30'),
(22, 1, 'Home Builder', 'homebuilder', 'HomeBuilderName', NULL, NULL, NULL, 0, 19, 1, '2016-09-30 03:58:10'),
(23, 1, 'Home Builder address', 'homebuilder', 'HomeBuilderAddress', NULL, NULL, NULL, 0, 20, 1, '2016-09-30 03:58:10'),
(24, 1, 'Home Builder Telephone', 'homebuilder', 'HomeBuilderPhone', NULL, NULL, NULL, 0, 21, 1, '2016-09-30 03:58:10'),
(25, 1, 'Home Builder Website', 'homebuilder', 'HomeBuilderPhone', NULL, NULL, NULL, 0, 22, 1, '2016-09-30 03:58:11'),
(26, 1, 'Foundation type', 'propertymain', 'PropertyFoundationType', NULL, NULL, NULL, 0, 23, 1, '2016-09-30 03:58:11'),
(27, 1, 'Number of Bedrooms', 'propertymain', 'PropertyNumberOfRoom', NULL, NULL, NULL, 0, 24, 1, '2016-09-30 03:58:11'),
(28, 1, 'Number of Baths', 'propertymain', 'PropertyNumberOfBath', NULL, NULL, NULL, 0, 25, 1, '2016-09-30 03:58:11'),
(29, 1, 'Number of Living Areas', 'propertymain', 'PropertyLivingArea', NULL, NULL, NULL, 0, 26, 1, '2016-09-30 03:58:11'),
(30, 1, 'Garage', 'propertymain', 'PropertyGarage', NULL, NULL, NULL, 0, 27, 1, '2016-09-30 04:17:01'),
(31, 1, 'Covered Patio', 'propertymain', 'PropertyCoveredPatio', NULL, NULL, NULL, 0, 28, 1, '2016-09-30 04:17:02'),
(32, 1, 'Open Patio\\Deck', 'propertymain', 'PropertyOpenPatio', NULL, NULL, NULL, 0, 29, 1, '2016-09-30 04:17:02'),
(33, 1, 'Type of Parking', 'parking', 'ParkingType', NULL, NULL, NULL, 0, 30, 1, '2016-09-30 04:17:03'),
(34, 1, 'Subfield - Quantity', 'parking', 'ParkingQty', NULL, NULL, NULL, 0, 31, 1, '2016-09-30 04:17:39'),
(35, 1, 'Swimming Pool', 'propertymain', 'PropertySwimming', NULL, NULL, NULL, 0, 32, 1, '2016-09-30 04:18:15'),
(36, 1, 'Storage building', 'propertymain', '', NULL, NULL, NULL, 1, 33, 1, '2016-09-30 04:18:16'),
(37, 1, 'Miscellaneous', '', NULL, NULL, NULL, NULL, 1, 34, 1, '2016-09-30 04:18:16'),
(38, 1, 'Miscellaneous #2', NULL, NULL, NULL, NULL, NULL, 1, 35, 1, '2016-09-30 04:18:16'),
(39, 1, 'Permits', 'propertypermit', '', NULL, NULL, NULL, 1, 36, 1, '2016-09-30 04:18:17'),
(40, 1, 'Water Source', 'propertymain', 'PropertyWaterSource', NULL, NULL, NULL, 0, 37, 1, '2016-09-30 04:18:17'),
(41, 1, 'Sewer Source', 'propertymain', 'PropertySewerSource', NULL, NULL, NULL, 0, 38, 1, '2016-09-30 04:18:17'),
(42, 1, 'Natural Gas', 'propertymain', 'PropertyHasGas', NULL, NULL, NULL, 0, 39, 1, '2016-09-30 04:18:17'),
(43, 1, 'Propane', 'propertymain', 'PropertyPropane', NULL, NULL, NULL, 0, 40, 1, '2016-09-30 04:18:17'),
(44, 1, 'Electric', 'propertymain', 'PropertyElectricitySource', NULL, NULL, NULL, 0, 41, 1, '2016-09-30 04:19:09'),
(45, 1, 'Survey', 'propertymain', '', NULL, NULL, NULL, 1, 42, 1, '2016-09-30 04:19:10'),
(46, 1, 'Environmental Reports', NULL, NULL, NULL, NULL, NULL, 1, 43, 1, '2016-09-30 04:19:11'),
(47, 1, 'Structural Reports', NULL, NULL, NULL, NULL, NULL, 1, 44, 1, '2016-09-30 04:19:12'),
(48, 1, 'Foundation Reports', NULL, NULL, NULL, NULL, NULL, 1, 45, 1, '2016-09-30 04:19:35'),
(49, 1, 'Easements', NULL, NULL, NULL, NULL, NULL, 1, 46, 1, '2016-09-30 04:19:36'),
(50, 1, 'Wetlands Reports', NULL, NULL, NULL, NULL, NULL, 1, 47, 1, '2016-09-30 04:19:37'),
(51, 1, 'Endangered Species Reports', NULL, NULL, NULL, NULL, NULL, 1, 48, 1, '2016-09-30 04:19:38'),
(52, 1, 'Community Site Plan', NULL, NULL, NULL, NULL, NULL, 1, 49, 1, '2016-09-30 04:19:38'),
(53, 1, 'Mineral Rights Deed\\Leases', 'propertydocuments', '', NULL, NULL, NULL, 0, 50, 1, '2016-09-30 04:19:39'),
(54, 1, 'Leases', NULL, NULL, NULL, NULL, NULL, 0, 51, 1, '2016-09-30 04:20:28'),
(55, 1, 'Miscellaneous Activity Field', 'propertyactivity', 'PropertyActivityDescription', NULL, NULL, NULL, 0, 52, 1, '2016-09-30 04:20:28'),
(57, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, '2016-10-08 05:01:06'),
(58, 5, 'sample pattern', 'pricecomparison', 'PriceComparisonCompany', 2, NULL, NULL, 1, 1, 1, '2016-10-08 06:48:40');

-- --------------------------------------------------------

--
-- Table structure for table `wx_template_flags`
--

CREATE TABLE IF NOT EXISTS `wx_template_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `priority` int(11) NOT NULL,
  `db_hint_for_needed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `wx_template_flags`
--

INSERT INTO `wx_template_flags` (`id`, `name`, `priority`, `db_hint_for_needed`, `notes`, `date_created`) VALUES
(1, 'Main', 0, NULL, 'This is the first part of the form where most of the data is expected to goto the main table', '2016-10-07'),
(2, 'Parking', 1, NULL, 'This is for the parking subfields', '2016-10-07');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `app_settings`
--
ALTER TABLE `app_settings`
  ADD CONSTRAINT `app_settings_ibfk_1` FOREIGN KEY (`wx_template_id`) REFERENCES `wx_templates` (`id`);

--
-- Constraints for table `contractor`
--
ALTER TABLE `contractor`
  ADD CONSTRAINT `fk_Contractor_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `homebuilder`
--
ALTER TABLE `homebuilder`
  ADD CONSTRAINT `fk_HomeBuilder_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `parking`
--
ALTER TABLE `parking`
  ADD CONSTRAINT `fk_Parking_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Parking_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pricecomparison`
--
ALTER TABLE `pricecomparison`
  ADD CONSTRAINT `fk_PriceComparison_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyactivity`
--
ALTER TABLE `propertyactivity`
  ADD CONSTRAINT `fk_PropertyActivity_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyActivity_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyconstruction`
--
ALTER TABLE `propertyconstruction`
  ADD CONSTRAINT `fk_PropertyConstruction_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyConstruction_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertydeed`
--
ALTER TABLE `propertydeed`
  ADD CONSTRAINT `fk_PropertyDeed_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyDeed_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertydocuments`
--
ALTER TABLE `propertydocuments`
  ADD CONSTRAINT `fk_PropertyDocuments_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyDocuments_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertygf`
--
ALTER TABLE `propertygf`
  ADD CONSTRAINT `fk_PropertyGF_PropertyMain` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyGF_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyitem`
--
ALTER TABLE `propertyitem`
  ADD CONSTRAINT `fk_PropertyItem_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyiteminstallation`
--
ALTER TABLE `propertyiteminstallation`
  ADD CONSTRAINT `fk_PropertyItemInstallation_Contractor1` FOREIGN KEY (`PropertyContractorId`) REFERENCES `contractor` (`ContractorId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_PropertyConstruction1` FOREIGN KEY (`PropertyConstructionId`) REFERENCES `propertyconstruction` (`PropertyConstructionId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyiteminstallation_has_propertyitem`
--
ALTER TABLE `propertyiteminstallation_has_propertyitem`
  ADD CONSTRAINT `fk_PropertyItemInstallation_has_PropertyItem_PropertyItem1` FOREIGN KEY (`PropertyItem_PropertyItemId`) REFERENCES `propertyitem` (`PropertyItemId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_has_PropertyItem_PropertyItemInst1` FOREIGN KEY (`PropertyItemInstallation_PropertyItemInstallationId`) REFERENCES `propertyiteminstallation` (`PropertyItemInstallationId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertymain`
--
ALTER TABLE `propertymain`
  ADD CONSTRAINT `fk_PropertyMain_HomeBuilder1` FOREIGN KEY (`PropertyBuilderId`) REFERENCES `homebuilder` (`HomeBuilderId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyMain_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertypaint`
--
ALTER TABLE `propertypaint`
  ADD CONSTRAINT `fk_PropertyPaint_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyPaint_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertypermit`
--
ALTER TABLE `propertypermit`
  ADD CONSTRAINT `fk_PropertyPermit_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `storage`
--
ALTER TABLE `storage`
  ADD CONSTRAINT `fk_Storage_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Storage_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `swimmingpool`
--
ALTER TABLE `swimmingpool`
  ADD CONSTRAINT `fk_SwimmingPool_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_SwimmingPool_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `uscity`
--
ALTER TABLE `uscity`
  ADD CONSTRAINT `fk_USCity_USCounty1` FOREIGN KEY (`CountyId`) REFERENCES `uscounty` (`USCountyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_USCity_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `uscounty`
--
ALTER TABLE `uscounty`
  ADD CONSTRAINT `fk_USCounty_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_USCounty_UState1` FOREIGN KEY (`StateId`) REFERENCES `ustate` (`UStateId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ustate`
--
ALTER TABLE `ustate`
  ADD CONSTRAINT `fk_UState_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `fk_WishList_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `wx_batch_updates`
--
ALTER TABLE `wx_batch_updates`
  ADD CONSTRAINT `wx_batch_updates_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `wx_batch` (`id`);

--
-- Constraints for table `wx_template_columns`
--
ALTER TABLE `wx_template_columns`
  ADD CONSTRAINT `wx_template_columns_ibfk_1` FOREIGN KEY (`wx_template_id`) REFERENCES `wx_templates` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_2` FOREIGN KEY (`flag_needed_a`) REFERENCES `wx_template_flags` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_3` FOREIGN KEY (`flag_needed_b`) REFERENCES `wx_template_flags` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_4` FOREIGN KEY (`app_user_id`) REFERENCES `app_users` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_5` FOREIGN KEY (`flag_to_raise`) REFERENCES `wx_template_flags` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
