-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 10, 2016 at 06:52 AM
-- Server version: 5.5.52-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbfadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_email`
--

CREATE TABLE IF NOT EXISTS `app_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(100) NOT NULL,
  `smtp_server` varchar(100) NOT NULL,
  `smtp_port` int(10) NOT NULL,
  `email_login` varchar(150) NOT NULL,
  `email_pass` varchar(100) NOT NULL,
  `from_name` varchar(100) NOT NULL,
  `from_email` varchar(150) NOT NULL,
  `transport` varchar(255) NOT NULL,
  `verify_url` varchar(255) NOT NULL,
  `email_act` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `app_email`
--

INSERT INTO `app_email` (`id`, `website_name`, `smtp_server`, `smtp_port`, `email_login`, `email_pass`, `from_name`, `from_email`, `transport`, `verify_url`, `email_act`) VALUES
(1, 'emailsrvr.com', 'smtp.emailsrvr.com', 587, 'info@gokabam.com', 'apple-daily-8', 'DBF App', 'info@gokabam.com', 'tls', 'http://localhost/dbfadmin/', 0);

-- --------------------------------------------------------

--
-- Table structure for table `app_keys`
--

CREATE TABLE IF NOT EXISTS `app_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stripe_ts` varchar(255) NOT NULL,
  `stripe_tp` varchar(255) NOT NULL,
  `stripe_ls` varchar(255) NOT NULL,
  `stripe_lp` varchar(255) NOT NULL,
  `recap_pub` varchar(100) NOT NULL,
  `recap_pri` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `app_pages`
--

CREATE TABLE IF NOT EXISTS `app_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(100) NOT NULL,
  `private` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `app_pages`
--

INSERT INTO `app_pages` (`id`, `page`, `private`) VALUES
(1, 'index.php', 0),
(2, 'z_us_root.php', 0),
(3, 'users/account.php', 1),
(4, 'users/admin.php', 1),
(5, 'users/admin_page.php', 1),
(6, 'users/admin_pages.php', 1),
(7, 'users/admin_permission.php', 1),
(8, 'users/admin_permissions.php', 1),
(9, 'users/admin_user.php', 1),
(10, 'users/admin_users.php', 1),
(11, 'users/edit_profile.php', 1),
(12, 'users/email_settings.php', 1),
(13, 'users/email_test.php', 1),
(14, 'users/forgot_password.php', 0),
(15, 'users/forgot_password_reset.php', 0),
(16, 'users/index.php', 0),
(17, 'users/init.php', 0),
(18, 'users/join.php', 0),
(19, 'users/joinThankYou.php', 0),
(20, 'users/login.php', 0),
(21, 'users/logout.php', 0),
(22, 'users/profile.php', 1),
(23, 'users/times.php', 0),
(24, 'users/user_settings.php', 1),
(25, 'users/verify.php', 0),
(26, 'users/verify_resend.php', 0),
(27, 'users/view_all_users.php', 1),
(28, 'usersc/empty.php', 0),
(29, 'info.php', 0),
(30, 'users/private_init.example.php', 0),
(31, 'users/private_init.php', 0),
(33, 'pages/index.php', 0),
(34, 'pages/status.php', 1),
(35, 'pages/mappings.php', 1),
(37, 'pages/upload.php', 1),
(38, 'pages/validate.php', 1),
(42, 'pages/ajax_aliases.php', 1),
(43, 'pages/alias_column_grid.php', 1),
(44, 'pages/last_property_dump.php', 1),
(45, 'pages/upload_history.php', 1),
(46, 'pages/ajax_templates.php', 1),
(47, 'pages/template_grid.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `app_permissions`
--

CREATE TABLE IF NOT EXISTS `app_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `app_permissions`
--

INSERT INTO `app_permissions` (`id`, `name`) VALUES
(1, 'User'),
(2, 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `app_permission_page_matches`
--

CREATE TABLE IF NOT EXISTS `app_permission_page_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(15) NOT NULL,
  `page_id` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `app_permission_page_matches`
--

INSERT INTO `app_permission_page_matches` (`id`, `permission_id`, `page_id`) VALUES
(2, 2, 27),
(3, 1, 24),
(4, 1, 22),
(5, 2, 13),
(6, 2, 12),
(7, 1, 11),
(8, 2, 10),
(9, 2, 9),
(10, 2, 8),
(11, 2, 7),
(12, 2, 6),
(13, 2, 5),
(14, 2, 4),
(15, 1, 3),
(16, 1, 34),
(17, 2, 34),
(18, 2, 35),
(19, 2, 36),
(20, 1, 37),
(21, 2, 37),
(22, 1, 38),
(23, 2, 38),
(24, 2, 39),
(25, 2, 40),
(26, 2, 41),
(27, 2, 42),
(28, 2, 43),
(29, 1, 44),
(30, 2, 44),
(31, 1, 45),
(32, 2, 45),
(33, 2, 47),
(34, 2, 46);

-- --------------------------------------------------------

--
-- Table structure for table `app_profiles`
--

CREATE TABLE IF NOT EXISTS `app_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bio` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `app_profiles`
--

INSERT INTO `app_profiles` (`id`, `user_id`, `bio`) VALUES
(1, 1, '<h1>This is the Admin''s bio.</h1>'),
(2, 2, 'This is your bio'),
(18, 18, 'This is your bio');

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE IF NOT EXISTS `app_settings` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `recaptcha` int(1) NOT NULL DEFAULT '0',
  `force_ssl` int(1) NOT NULL,
  `login_type` varchar(20) NOT NULL,
  `css_sample` int(1) NOT NULL,
  `us_css1` varchar(255) NOT NULL,
  `us_css2` varchar(255) NOT NULL,
  `us_css3` varchar(255) NOT NULL,
  `css1` varchar(255) NOT NULL,
  `css2` varchar(255) NOT NULL,
  `css3` varchar(255) NOT NULL,
  `site_name` varchar(100) NOT NULL,
  `language` varchar(255) NOT NULL,
  `track_guest` int(1) NOT NULL,
  `site_offline` int(1) NOT NULL,
  `force_pr` int(1) NOT NULL,
  `reserved1` varchar(100) NOT NULL,
  `reserverd2` varchar(100) NOT NULL,
  `custom1` varchar(100) NOT NULL,
  `custom2` varchar(100) NOT NULL,
  `custom3` varchar(100) NOT NULL,
  `wx_template_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wx_template_id` (`wx_template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `app_settings`
--

INSERT INTO `app_settings` (`id`, `recaptcha`, `force_ssl`, `login_type`, `css_sample`, `us_css1`, `us_css2`, `us_css3`, `css1`, `css2`, `css3`, `site_name`, `language`, `track_guest`, `site_offline`, `force_pr`, `reserved1`, `reserverd2`, `custom1`, `custom2`, `custom3`, `wx_template_id`) VALUES
(1, 1, 0, '', 1, '../users/css/color_schemes/standard.css', '../users/css/sb-admin.css', '../users/css/custom.css', '', '', '', 'DBF Imports', 'en', 0, 0, 0, '', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `app_users`
--

CREATE TABLE IF NOT EXISTS `app_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(155) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `permissions` int(11) NOT NULL,
  `logins` int(100) NOT NULL,
  `account_owner` tinyint(4) NOT NULL DEFAULT '0',
  `account_id` int(11) NOT NULL DEFAULT '0',
  `company` varchar(255) NOT NULL,
  `stripe_cust_id` varchar(255) NOT NULL,
  `billing_phone` varchar(20) NOT NULL,
  `billing_srt1` varchar(255) NOT NULL,
  `billing_srt2` varchar(255) NOT NULL,
  `billing_city` varchar(255) NOT NULL,
  `billing_state` varchar(255) NOT NULL,
  `billing_zip_code` varchar(255) NOT NULL,
  `join_date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `email_verified` tinyint(4) NOT NULL DEFAULT '0',
  `vericode` varchar(15) NOT NULL,
  `title` varchar(100) NOT NULL,
  `active` int(1) NOT NULL,
  `custom1` varchar(255) NOT NULL,
  `custom2` varchar(255) NOT NULL,
  `custom3` varchar(255) NOT NULL,
  `custom4` varchar(255) NOT NULL,
  `custom5` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `EMAIL` (`email`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `app_users`
--

INSERT INTO `app_users` (`id`, `email`, `username`, `password`, `fname`, `lname`, `permissions`, `logins`, `account_owner`, `account_id`, `company`, `stripe_cust_id`, `billing_phone`, `billing_srt1`, `billing_srt2`, `billing_city`, `billing_state`, `billing_zip_code`, `join_date`, `last_login`, `email_verified`, `vericode`, `title`, `active`, `custom1`, `custom2`, `custom3`, `custom4`, `custom5`) VALUES
(1, 'userspicephp@gmail.com', 'admin', '$2y$12$9R4u4lVraHZeJJ6YVJxO4e43./LZQLwC3VVlS1BvSN1IsZJDOooFK', 'Admin', 'User', 1, 7, 1, 0, 'UserSpice', '', '', '', '', '', '', '', '2016-01-01 00:00:00', '2016-10-08 00:16:07', 1, '322418', '', 0, '', '', '', '', ''),
(2, 'noreply@userspice.com', 'user', '$2y$12$HZa0/d7evKvuHO8I3U8Ff.pOjJqsGTZqlX8qURratzP./EvWetbkK', 'user', 'user', 1, 0, 1, 0, 'none', '', '', '', '', '', '', '', '2016-01-02 00:00:00', '2016-01-02 00:00:00', 1, '970748', '', 1, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `app_users_online`
--

CREATE TABLE IF NOT EXISTS `app_users_online` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `timestamp` varchar(15) NOT NULL,
  `user_id` int(10) NOT NULL,
  `session` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `app_users_session`
--

CREATE TABLE IF NOT EXISTS `app_users_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `uagent` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `app_users_session`
--

INSERT INTO `app_users_session` (`id`, `user_id`, `hash`, `uagent`) VALUES
(38, 1, 'e5c284103ce354831561e3b447d1758976c799922d7e20743e9f8c290dfe078f', 'Mozilla (Windows NT 6.1; Win64; x64) AppleWebKit (KHTML, like Gecko) Chrome Safari'),
(39, 1, '6523a6faed7f03a1a7e96173a332d64da4cd477dd8997c7e36967eb81d2ed253', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:48.0) Gecko Firefox'),
(40, 1, 'd9d630707a976b27d5b7edfe8d99f75e611ff07c46c91d238d047301cb817a59', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox'),
(41, 1, 'f1e80d8c93a54f882d6235609d86b3e4e353554126b02d10a7dca3b15b97faf9', 'Mozilla (X11; Linux x86_64) AppleWebKit (KHTML, like Gecko) Chrome Safari'),
(42, 1, '150f42fc139b188dba7fc9b2f9e22011d08a7aeee7e347b5ccd446a32264df28', 'Mozilla (X11; Ubuntu; Linux x86_64; rv:49.0) Gecko Firefox');

-- --------------------------------------------------------

--
-- Table structure for table `app_user_permission_matches`
--

CREATE TABLE IF NOT EXISTS `app_user_permission_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `app_user_permission_matches`
--

INSERT INTO `app_user_permission_matches` (`id`, `user_id`, `permission_id`) VALUES
(100, 1, 1),
(101, 1, 2),
(102, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contractor`
--

CREATE TABLE IF NOT EXISTS `contractor` (
  `ContractorId` int(12) NOT NULL AUTO_INCREMENT,
  `ContractorName` varchar(120) NOT NULL,
  `ContractorAddress` varchar(200) DEFAULT NULL,
  `ContractorPhone` varchar(50) DEFAULT NULL,
  `ContractorType` varchar(1) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`ContractorId`),
  KEY `fk_Contractor_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `homebuilder`
--

CREATE TABLE IF NOT EXISTS `homebuilder` (
  `HomeBuilderId` int(12) NOT NULL AUTO_INCREMENT,
  `HomeBuilderName` varchar(80) NOT NULL,
  `HomeBuilderAddress` varchar(120) DEFAULT NULL,
  `HomeBuilderPhone` varchar(50) DEFAULT NULL,
  `LogoAddress` varchar(120) DEFAULT NULL,
  `WebsiteAddress` varchar(120) DEFAULT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`HomeBuilderId`),
  KEY `fk_HomeBuilder_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `parking`
--

CREATE TABLE IF NOT EXISTS `parking` (
  `ParkingId` int(12) NOT NULL AUTO_INCREMENT,
  `ParkingType` varchar(2) NOT NULL,
  `ParkingQty` int(2) NOT NULL,
  `ParkingDescription` varchar(120) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`ParkingId`),
  KEY `fk_Parking_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_Parking_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pricecomparison`
--

CREATE TABLE IF NOT EXISTS `pricecomparison` (
  `PriceComparisonId` int(12) NOT NULL AUTO_INCREMENT,
  `PriceComparisonDescription` varchar(80) DEFAULT NULL,
  `PriceComparisonBarCode` varchar(50) DEFAULT NULL,
  `PriceComparisonCompany` varchar(80) DEFAULT NULL,
  `PriceComparisonAddress` varchar(120) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PriceComparisonId`),
  KEY `fk_PriceComparison_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyactivity`
--

CREATE TABLE IF NOT EXISTS `propertyactivity` (
  `PropertyActivityId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyActivityDate` date NOT NULL,
  `ContractorId` int(12) NOT NULL,
  `PropertyActivityDescription` varchar(200) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyActivityId`),
  KEY `fk_PropertyActivity_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyActivity_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyconstruction`
--

CREATE TABLE IF NOT EXISTS `propertyconstruction` (
  `PropertyConstructionId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyConstructionDescription` varchar(120) NOT NULL,
  `PropertyConstructionDate` date NOT NULL,
  `PropertyConstructionFloor` int(2) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyConstructionId`),
  KEY `fk_PropertyConstruction_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyConstruction_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertydeed`
--

CREATE TABLE IF NOT EXISTS `propertydeed` (
  `PropertyDeedId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyDeedDate` date NOT NULL,
  `PropertyDeedNumber` varchar(50) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyDeedId`),
  KEY `fk_PropertyDeed_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyDeed_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertydocuments`
--

CREATE TABLE IF NOT EXISTS `propertydocuments` (
  `PropertyDocumentId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyDocumentType` varchar(2) NOT NULL,
  `PropertyDocumentDate` date NOT NULL,
  `PropertyDocumentAddress` varchar(200) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyDocumentId`),
  KEY `fk_PropertyDocuments_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyDocuments_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertygf`
--

CREATE TABLE IF NOT EXISTS `propertygf` (
  `PropertyGFId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyGFNumber` varchar(50) NOT NULL,
  `PropertyGFDate` date NOT NULL,
  `PropertyGFDescription` varchar(120) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyGFId`),
  KEY `fk_PropertyGF_PropertyMain_idx` (`PropertyId`),
  KEY `fk_PropertyGF_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyitem`
--

CREATE TABLE IF NOT EXISTS `propertyitem` (
  `PropertyItemId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyItemName` varchar(120) NOT NULL,
  `PropertyItemStorePurchased` varchar(120) DEFAULT NULL,
  `PropertyItemBarcode` varchar(50) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyItemId`),
  KEY `fk_PropertyItem_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyiteminstallation`
--

CREATE TABLE IF NOT EXISTS `propertyiteminstallation` (
  `PropertyItemInstallationId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyItemInstallationDate` date NOT NULL,
  `PropertyItemId` int(12) NOT NULL,
  `AnyDescription` varchar(120) DEFAULT NULL,
  `PropertyContractorId` int(12) NOT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Brand` varchar(50) DEFAULT NULL,
  `FinishType` varchar(50) DEFAULT NULL,
  `Manufacturer` varchar(80) DEFAULT NULL,
  `Model` varchar(50) DEFAULT NULL,
  `Qty` int(5) DEFAULT NULL,
  `DateInstalled` date NOT NULL,
  `Warranty` int(3) DEFAULT NULL,
  `PropertyConstructionId` int(12) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyItemInstallationId`),
  KEY `fk_PropertyItemInstallation_Contractor1_idx` (`PropertyContractorId`),
  KEY `fk_PropertyItemInstallation_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyItemInstallation_PropertyConstruction1_idx` (`PropertyConstructionId`),
  KEY `fk_PropertyItemInstallation_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertyiteminstallation_has_propertyitem`
--

CREATE TABLE IF NOT EXISTS `propertyiteminstallation_has_propertyitem` (
  `PropertyItemInstallation_PropertyItemInstallationId` int(12) NOT NULL,
  `PropertyItem_PropertyItemId` int(12) NOT NULL,
  PRIMARY KEY (`PropertyItemInstallation_PropertyItemInstallationId`,`PropertyItem_PropertyItemId`),
  KEY `fk_PropertyItemInstallation_has_PropertyItem_PropertyItem1_idx` (`PropertyItem_PropertyItemId`),
  KEY `fk_PropertyItemInstallation_has_PropertyItem_PropertyItemIn_idx` (`PropertyItemInstallation_PropertyItemInstallationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `propertymain`
--

CREATE TABLE IF NOT EXISTS `propertymain` (
  `PropertyId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyType` varchar(1) DEFAULT NULL,
  `PropertySubType` varchar(30) DEFAULT NULL,
  `PropertyOwnNumber` varchar(10) DEFAULT NULL,
  `PropertyCountry` varchar(50) DEFAULT NULL,
  `PropertyZipCode` varchar(50) DEFAULT NULL,
  `PropertyState` varchar(50) DEFAULT NULL,
  `PropertyCounty` varchar(50) DEFAULT NULL,
  `PropertyCity` varchar(120) DEFAULT NULL,
  `PropertyNeighborhood` varchar(255) DEFAULT NULL,
  `PropertyStreetNumber` varchar(255) DEFAULT NULL,
  `PropertyStreetName` varchar(255) DEFAULT NULL,
  `PropertyStreetDirectionSuffix` varchar(255) DEFAULT NULL,
  `PropertyStreetType` varchar(255) DEFAULT NULL,
  `PropertyBlock` varchar(25) DEFAULT NULL,
  `PropertyLot` varchar(30) DEFAULT NULL,
  `PropertySubDivision` varchar(50) DEFAULT NULL,
  `PropertyParcelNumber` varchar(255) DEFAULT NULL,
  `PropertySubType2` varchar(255) DEFAULT NULL,
  `PropertyParcelZoning` varchar(255) DEFAULT NULL,
  `PropertyParcelUse` varchar(255) DEFAULT NULL,
  `PropertyAcres` varchar(255) DEFAULT NULL,
  `PropertyBuildingStyle` varchar(255) DEFAULT NULL,
  `PropertyNumberOfUnits` varchar(255) DEFAULT NULL,
  `PropertyLegalDescription` varchar(300) DEFAULT NULL,
  `PropertyLegal2` varchar(255) DEFAULT NULL,
  `PropertyLegal3` varchar(255) DEFAULT NULL,
  `PropertyTaxNumber` varchar(80) DEFAULT NULL,
  `PropertyBuiltYear` int(4) DEFAULT NULL,
  `PropertyBuilderId` int(12) DEFAULT NULL,
  `PropertyNumberOfRoom` int(4) DEFAULT NULL,
  `PropertyNumberOfBath` int(4) DEFAULT NULL,
  `PropertyNumberOfStory` int(4) DEFAULT NULL,
  `PropertyLandSQFT` decimal(15,4) DEFAULT NULL,
  `PropertyLivingArea` int(4) DEFAULT NULL,
  `PropertyGarage` varchar(1) DEFAULT NULL,
  `PropertyCoveredPatio` varchar(1) DEFAULT NULL,
  `PropertyOpenPatio` varchar(1) DEFAULT NULL,
  `PropertyWaterSource` varchar(50) DEFAULT NULL,
  `PropertySewerSource` varchar(50) DEFAULT NULL,
  `PropertyHasGas` varchar(30) DEFAULT NULL,
  `PropertyPropane` varchar(1) DEFAULT NULL,
  `PropertyElectricitySource` varchar(50) DEFAULT NULL,
  `PropertylongLocation` decimal(18,14) DEFAULT NULL,
  `PropertyLatLocation` decimal(18,14) DEFAULT NULL,
  `PropertyGeographicCodeX` varchar(255) DEFAULT NULL,
  `PropertyGeographicCodeY` varchar(255) DEFAULT NULL,
  `PropertyConstructionType` varchar(2) DEFAULT NULL,
  `PropertyFoundationType` varchar(2) DEFAULT NULL,
  `PropertySwimming` int(1) DEFAULT NULL,
  `PropertyPictures` varchar(255) DEFAULT NULL,
  `PropertyNewHomeSelectionSheet` varchar(255) DEFAULT NULL,
  `PropertyLinkTaxAssessorData` varchar(255) DEFAULT NULL,
  `EntryDate` date DEFAULT NULL,
  `UserId` int(9) DEFAULT NULL,
  PRIMARY KEY (`PropertyId`),
  KEY `fk_PropertyMain_HomeBuilder1_idx` (`PropertyBuilderId`),
  KEY `fk_PropertyMain_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertypaint`
--

CREATE TABLE IF NOT EXISTS `propertypaint` (
  `PropertyPaintId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyPaintDate` date NOT NULL,
  `PropertyItemPaintFor` varchar(80) NOT NULL,
  `PropertyPaintBrand` varchar(50) DEFAULT NULL,
  `PropertyPaintColor` varchar(50) DEFAULT NULL,
  `PropertyPaintFinishType` varchar(2) DEFAULT NULL,
  `Manufacturer` varchar(80) DEFAULT NULL,
  `PropertyPaintDateInstalled` date DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `PropertyConstructionId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`PropertyPaintId`),
  KEY `fk_PropertyPaint_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_PropertyPaint_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `propertypermit`
--

CREATE TABLE IF NOT EXISTS `propertypermit` (
  `PropertyPermitId` int(12) NOT NULL AUTO_INCREMENT,
  `PropertyPermitNumber` varchar(50) NOT NULL,
  `PropertyPermitDate` date NOT NULL,
  `PropertyPermitDescription` varchar(120) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `UserId` int(9) NOT NULL,
  `EntryDate` date NOT NULL,
  PRIMARY KEY (`PropertyPermitId`),
  KEY `fk_PropertyPermit_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `storage`
--

CREATE TABLE IF NOT EXISTS `storage` (
  `StorageId` int(12) NOT NULL,
  `StorageType` varchar(1) NOT NULL,
  `StorageQty` int(2) DEFAULT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`StorageId`),
  KEY `fk_Storage_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_Storage_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `swimmingpool`
--

CREATE TABLE IF NOT EXISTS `swimmingpool` (
  `SwimmingPool_Id` int(12) NOT NULL AUTO_INCREMENT,
  `SwimmingPoolType` varchar(1) NOT NULL,
  `SwimmingPoolQty` int(2) NOT NULL,
  `PropertyId` int(12) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`SwimmingPool_Id`),
  KEY `fk_SwimmingPool_PropertyMain1_idx` (`PropertyId`),
  KEY `fk_SwimmingPool_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uscity`
--

CREATE TABLE IF NOT EXISTS `uscity` (
  `USCityId` int(11) NOT NULL AUTO_INCREMENT,
  `USCityName` varchar(120) NOT NULL,
  `CountyId` int(6) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`USCityId`),
  KEY `fk_USCity_USCounty1_idx` (`CountyId`),
  KEY `fk_USCity_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uscounty`
--

CREATE TABLE IF NOT EXISTS `uscounty` (
  `USCountyId` int(6) NOT NULL AUTO_INCREMENT,
  `USCountyName` varchar(80) NOT NULL,
  `StateId` int(3) DEFAULT NULL,
  `EntryDate` date DEFAULT NULL,
  `UserId` int(9) DEFAULT NULL,
  PRIMARY KEY (`USCountyId`),
  KEY `fk_USCounty_UState1_idx` (`StateId`),
  KEY `fk_USCounty_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `UserId` int(9) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(80) NOT NULL,
  `UserPassword` varchar(30) NOT NULL,
  `DateCreated` date NOT NULL,
  `UserStateCode` varchar(2) NOT NULL,
  `UserType` varchar(3) NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ustate`
--

CREATE TABLE IF NOT EXISTS `ustate` (
  `UStateId` int(3) NOT NULL AUTO_INCREMENT,
  `UStateName` varchar(50) NOT NULL,
  `UStateCode` varchar(2) NOT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`UStateId`),
  KEY `fk_UState_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE IF NOT EXISTS `wishlist` (
  `WishListId` int(12) NOT NULL AUTO_INCREMENT,
  `WishListDescription` varchar(80) DEFAULT NULL,
  `WishListBarCode` varchar(50) DEFAULT NULL,
  `WishListCompany` varchar(80) DEFAULT NULL,
  `WishListCompanyAddress` varchar(120) DEFAULT NULL,
  `EntryDate` date NOT NULL,
  `UserId` int(9) NOT NULL,
  PRIMARY KEY (`WishListId`),
  KEY `fk_WishList_Users1_idx` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wx_batch`
--

CREATE TABLE IF NOT EXISTS `wx_batch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_user_id` int(11) NOT NULL,
  `wx_template_id` int(11) NOT NULL,
  `batch_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'normal' COMMENT 'choice of normal,dryrun',
  `original_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_error` tinyint(4) NOT NULL DEFAULT '1',
  `error_message` text COLLATE utf8_unicode_ci,
  `created_at_ts` int(11) NOT NULL,
  `finished_upload_at_ts` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `app_user_id` (`app_user_id`),
  KEY `is_error` (`is_error`),
  KEY `batch_type` (`batch_type`),
  KEY `wx_template_id` (`wx_template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=44 ;

--
-- Dumping data for table `wx_batch`
--

INSERT INTO `wx_batch` (`id`, `app_user_id`, `wx_template_id`, `batch_type`, `original_filename`, `is_error`, `error_message`, `created_at_ts`, `finished_upload_at_ts`, `notes`) VALUES
(1, 1, 1, 'normal', 'short.dbf', 0, NULL, 1475938583, NULL, NULL),
(2, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476032021, 1476036028, NULL),
(3, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Data Entry Person\\Source Code ;not_found: Property Identifier - Permanent ;not_found: Number Identifier - Flexible ;not_found: Property Type ;not_found: Property Sub-type ;not_found: Property Street Address ;not_found: Property Address #2 ;not_found: Property Address #3 ;not_found: Property City ;not_found: Property State ;not_found: Property Zip code ;not_found: Property County ;not_found: Property Country ;not_found: Property Subdivision ;not_found: Legal Description ;not_found: GF Number ;not_found: Tax ID - Account Number ;not_found: Geographical Coordinates ;not_found: Date of Deed - Transfer ;not_found: Floor Plan ;not_found: Date Built ;not_found: Type of Construction ;not_found: Home Builder ;not_found: Home Builder address ;not_found: Home Builder Telephone ;not_found: Home Builder Website ;not_found: Foundation type ;not_found: Number of Bedrooms ;not_found: Number of Baths ;not_found: Number of Living Areas ;not_found: Garage ;not_found: Covered Patio ;not_found: Open Patio\\Deck ;not_found: Type of Parking ;not_found: Subfield - Quantity ;not_found: Swimming Pool ;not_found: Storage building ;not_found: Miscellaneous ;not_found: Miscellaneous #2 ;not_found: Permits ;not_found: Water Source ;not_found: Sewer Source ;not_found: Natural Gas ;not_found: Propane ;not_found: Electric ;not_found: Survey ;not_found: Environmental Reports ;not_found: Structural Reports ;not_found: Foundation Reports ;not_found: Easements ;not_found: Wetlands Reports ;not_found: Endangered Species Reports ;not_found: Community Site Plan ;not_found: Warranty ;not_found: Mineral Rights Deed\\Leases ;not_found: Leases ;not_found: Miscellaneous Activity Field #1 ;not_found: Miscellaneous Activity Field #2 ;not_found: Miscellaneous Activity Field #3 ;not_found: Miscellaneous Activity Field #4 ;not_found: Miscellaneous Activity Field #5 ;not_found: Garage Door(s) ;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: Garage Opener ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Electrical ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Garage Doors ;not_found: Exterior Front Door ;not_found: Miscellaneous #1 ;not_found: Miscellaneous #3 ;not_found: Miscellaneous #4 ;not_found: Miscellaneous #5 ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476036046, 1476036182, NULL),
(4, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476036385, 1476036579, NULL),
(5, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476036595, 1476036784, NULL),
(6, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476036811, 1476036847, NULL),
(7, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476036857, 1476036914, NULL),
(8, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476036923, 1476037025, NULL),
(9, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476037035, 1476037114, NULL),
(10, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Data Entry Person\\Source Code ;not_found: Property Identifier - Permanent ;not_found: Number Identifier - Flexible ;not_found: Property Type ;not_found: Property Sub-type ;not_found: Property Street Address ;not_found: Property Address #2 ;not_found: Property Address #3 ;not_found: Property City ;not_found: Property State ;not_found: Property Zip code ;not_found: Property County ;not_found: Property Country ;not_found: Property Subdivision ;not_found: Legal Description ;not_found: GF Number ;not_found: Tax ID - Account Number ;not_found: Geographical Coordinates ;not_found: Date of Deed - Transfer ;not_found: Floor Plan ;not_found: Date Built ;not_found: Type of Construction ;not_found: Home Builder ;not_found: Home Builder address ;not_found: Home Builder Telephone ;not_found: Home Builder Website ;not_found: Foundation type ;not_found: Number of Bedrooms ;not_found: Number of Baths ;not_found: Number of Living Areas ;not_found: Garage ;not_found: Covered Patio ;not_found: Open Patio\\Deck ;not_found: Type of Parking ;not_found: Subfield - Quantity ;not_found: Swimming Pool ;not_found: Storage building ;not_found: Miscellaneous ;not_found: Miscellaneous #2 ;not_found: Permits ;not_found: Water Source ;not_found: Sewer Source ;not_found: Natural Gas ;not_found: Propane ;not_found: Electric ;not_found: Survey ;not_found: Environmental Reports ;not_found: Structural Reports ;not_found: Foundation Reports ;not_found: Easements ;not_found: Wetlands Reports ;not_found: Endangered Species Reports ;not_found: Community Site Plan ;not_found: Warranty ;not_found: Mineral Rights Deed\\Leases ;not_found: Leases ;not_found: Miscellaneous Activity Field #1 ;not_found: Miscellaneous Activity Field #2 ;not_found: Miscellaneous Activity Field #3 ;not_found: Miscellaneous Activity Field #4 ;not_found: Miscellaneous Activity Field #5 ;not_found: Garage Door(s) ;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: Garage Opener ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Electrical ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Garage Doors ;not_found: Exterior Front Door ;not_found: Miscellaneous #1 ;not_found: Miscellaneous #3 ;not_found: Miscellaneous #4 ;not_found: Miscellaneous #5 ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476037891, 1476037900, NULL),
(11, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476038024, 1476038120, NULL),
(12, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476038132, 1476038242, NULL),
(13, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476038252, 1476038350, NULL),
(14, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476038368, 1476038422, NULL),
(15, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476038433, 1476038578, NULL),
(16, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476038597, 1476038647, NULL),
(17, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476038719, 1476038930, NULL),
(18, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476039040, 1476039230, NULL),
(19, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476039260, 1476039393, NULL),
(20, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476039483, 1476039671, NULL),
(21, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476039842, 1476039955, NULL),
(22, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476039962, 1476040167, NULL),
(23, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476040180, 1476040496, NULL),
(24, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476040504, 1476040527, NULL),
(25, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476040542, 1476040580, NULL),
(26, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476040588, 1476040839, NULL),
(27, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476040890, 1476041063, NULL),
(28, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476041075, 1476041215, NULL),
(29, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476041224, 1476041507, NULL),
(30, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476041581, 1476041661, NULL),
(31, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476041670, 1476042410, NULL),
(32, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476042582, 1476042724, NULL),
(33, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476042731, 1476042972, NULL),
(34, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476042979, 1476043213, NULL),
(35, 1, 1, 'normal', 'short.dbf', 1, NULL, 1476043225, NULL, NULL),
(36, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476097641, 1476097926, NULL),
(37, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Number Identifier - Flexible ;not_found: Property Address #2 ;not_found: Property Address #3 ;conflict: Home Builder address 22,23;conflict: Home Builder Telephone 22,24;conflict: Home Builder Website 22,25;conflict: Miscellaneous #2 37,38;not_found: Warranty ;conflict: Mineral Rights Deed\\Leases 53,54;conflict: Miscellaneous Activity Field #1 37,55;conflict: Miscellaneous Activity Field #2 37,55;conflict: Miscellaneous Activity Field #3 37,55;conflict: Miscellaneous Activity Field #4 37,55;conflict: Miscellaneous Activity Field #5 37,55;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Front Door ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476097941, 1476098520, NULL),
(38, 1, 1, 'normal', 'short.dbf', 0, NULL, 1476098582, 1476098713, NULL),
(39, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Number Identifier - Flexible ;not_found: Property Address #2 ;not_found: Property Address #3 ;conflict: Home Builder address 22,23;conflict: Home Builder Telephone 22,24;conflict: Home Builder Website 22,25;conflict: Miscellaneous #2 37,38;not_found: Warranty ;conflict: Mineral Rights Deed\\Leases 53,54;conflict: Miscellaneous Activity Field #1 37,55;conflict: Miscellaneous Activity Field #2 37,55;conflict: Miscellaneous Activity Field #3 37,55;conflict: Miscellaneous Activity Field #4 37,55;conflict: Miscellaneous Activity Field #5 37,55;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Front Door ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476098721, 1476099103, NULL),
(40, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Number Identifier - Flexible ;not_found: Property Address #2 ;not_found: Property Address #3 ;conflict: Home Builder address 22,23;conflict: Home Builder Telephone 22,24;conflict: Home Builder Website 22,25;conflict: Miscellaneous #2 37,38;not_found: Warranty ;conflict: Mineral Rights Deed\\Leases 53,54;conflict: Miscellaneous Activity Field #1 37,55;conflict: Miscellaneous Activity Field #2 37,55;conflict: Miscellaneous Activity Field #3 37,55;conflict: Miscellaneous Activity Field #4 37,55;conflict: Miscellaneous Activity Field #5 37,55;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Front Door ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476099169, 1476099300, NULL),
(41, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Number Identifier - Flexible ;not_found: Property Address #2 ;not_found: Property Address #3 ;conflict: Home Builder address 22,23;conflict: Home Builder Telephone 22,24;conflict: Home Builder Website 22,25;conflict: Miscellaneous #2 37,38;not_found: Warranty ;conflict: Mineral Rights Deed\\Leases 53,54;conflict: Miscellaneous Activity Field #1 37,55;conflict: Miscellaneous Activity Field #2 37,55;conflict: Miscellaneous Activity Field #3 37,55;conflict: Miscellaneous Activity Field #4 37,55;conflict: Miscellaneous Activity Field #5 37,55;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Front Door ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476099319, 1476099323, NULL),
(42, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Number Identifier - Flexible ;not_found: Property Address #2 ;not_found: Property Address #3 ;conflict: Home Builder address 22,23;conflict: Home Builder Telephone 22,24;conflict: Home Builder Website 22,25;conflict: Miscellaneous #2 37,38;not_found: Warranty ;conflict: Mineral Rights Deed\\Leases 53,54;conflict: Miscellaneous Activity Field #1 37,55;conflict: Miscellaneous Activity Field #2 37,55;conflict: Miscellaneous Activity Field #3 37,55;conflict: Miscellaneous Activity Field #4 37,55;conflict: Miscellaneous Activity Field #5 37,55;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Front Door ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476099365, 1476099369, NULL),
(43, 1, 1, 'normal', 'short.dbf', 1, 'not_found: Number Identifier - Flexible ;not_found: Property Address #2 ;not_found: Property Address #3 ;conflict: Home Builder address 22,23;conflict: Home Builder Telephone 22,24;conflict: Home Builder Website 22,25;conflict: Miscellaneous #2 37,38;not_found: Warranty ;conflict: Mineral Rights Deed\\Leases 53,54;conflict: Miscellaneous Activity Field #1 37,55;conflict: Miscellaneous Activity Field #2 37,55;conflict: Miscellaneous Activity Field #3 37,55;conflict: Miscellaneous Activity Field #4 37,55;conflict: Miscellaneous Activity Field #5 37,55;not_found: Contractor ;not_found: Contractor address ;not_found: Contractor phone number ;not_found: Quantity ;not_found: Door Manufacturer ;not_found: Door Model Number ;not_found: Date installed ;not_found: System Manufacturer ;not_found: System Model Number ;not_found: Alarm System ;not_found: Foundation ;not_found: Type ;not_found: Windows ;not_found: Manufacturer ;not_found: Manufacturer address ;not_found: Manufacturer phone number ;not_found: Manufacturer website ;not_found: Model ;not_found: HVAC ;not_found: Furnace Manufacturer ;not_found: Furnace Model Numbers ;not_found: Condenser Manufacturer ;not_found: Condenser Model Number ;not_found: Date Installed ;not_found: Evaporator Coil Manufacturer ;not_found: Evaporator Coil Model Number ;not_found: Emergency Generator ;not_found: Model Numbers ;not_found: Septic System ;not_found: Water Well System ;not_found: Irrigation System ;not_found: Spa\\Hot Tub ;not_found: Sauna ;not_found: Plumbing Contractor ;not_found: Finish ;not_found: Faucet Brand \\ Manufacturer ;not_found: Appliances ;not_found: Painting ;not_found: Date work done ;not_found: Walls ;not_found: Brand ;not_found: Color ;not_found: Ceilings ;not_found: Doors and Trim ;not_found: Closet ;not_found: Bathrooms ;not_found: Cabinets ;not_found: Staircase and wood Trim Stain ;not_found: Exterior Trim ;not_found: Exterior Front Door ;not_found: Exterior Walls ;not_found: Brick manufacturer ;not_found: Siding ;not_found: Stone ;not_found: Kitchen Cabinets ;not_found: Finish Type ;not_found: Kitchen Countertop ;not_found: Master Bathroom Vanity Top ;not_found: Master Bathroom Vanity Cabinets ;not_found: Powder Room Countertop ;not_found: Powder Room Cabinets ;not_found: Bath #2 Countertop ;not_found: Bath # 2 Cabinets ;not_found: Fireplace #1 ;not_found: Fireplace #1 - Mantel & Surround ;not_found: Surround Type ;not_found: Surround Finish ;not_found: Surround Color ;not_found: Surround Brand ;not_found: Surround Manufacturer ;not_found: Hearth Type ;not_found: Hearth Finish ;not_found: Hearth Color ;not_found: Hearth Brand ;not_found: Hearth Manufacturer ;not_found: Living Room ;not_found: Flooring Type ;not_found: Wall Paint ;not_found: Accent Wall Paint ;not_found: Ceiling Paint ;not_found: Doors and Trim Paint ;not_found: Kitchen ;not_found: Family Room ;not_found: Dining Room ;not_found: Breakfast Room ;not_found: Game Room ;not_found: Master Bedroom ;not_found: Bedroom #2 ;not_found: Bedroom #3 ;not_found: Bedroom #4 ;not_found: Utility Room ;not_found: Master Bathroom ;not_found: Wall Tile ;not_found: 2nd Bathroom ;not_found: Powder Room ', 1476100276, 1476100279, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wx_batch_updates`
--

CREATE TABLE IF NOT EXISTS `wx_batch_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `name_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name_column` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_batch_updates_unique_entry` (`batch_id`,`name_table`,`name_column`),
  KEY `batch_id` (`batch_id`),
  KEY `idx_batch_update_tables` (`name_table`),
  KEY `idx_batch_update_column` (`name_column`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wx_templates`
--

CREATE TABLE IF NOT EXISTS `wx_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ts_created_at` int(11) NOT NULL,
  `ts_modified_at` int(11) DEFAULT NULL,
  `created_by_user_id` int(11) NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_user_id` (`created_by_user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='This table is for keeping track of the different templates' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `wx_templates`
--

INSERT INTO `wx_templates` (`id`, `name`, `ts_created_at`, `ts_modified_at`, `created_by_user_id`, `notes`) VALUES
(1, 'Single House Property', 1475907853, 1475908041, 1, 'The template that handles the data from the sample single house sheets'),
(5, 'Sample Second Template', 1475908074, 1475908093, 1, 'Sample');

-- --------------------------------------------------------

--
-- Table structure for table `wx_template_columns`
--

CREATE TABLE IF NOT EXISTS `wx_template_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wx_template_id` int(11) DEFAULT NULL,
  `name_regex_alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_table` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_column` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flag_to_raise` int(11) DEFAULT NULL,
  `flag_needed_a` int(11) DEFAULT NULL,
  `flag_needed_b` int(11) DEFAULT NULL,
  `is_ignored` int(11) NOT NULL DEFAULT '0',
  `rank` float NOT NULL DEFAULT '0',
  `app_user_id` int(11) NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `name_regex_alias` (`name_regex_alias`),
  KEY `app_user_id` (`app_user_id`),
  KEY `rank` (`rank`),
  KEY `template_id_in_columns` (`wx_template_id`),
  KEY `flag_to_raise` (`flag_to_raise`),
  KEY `flag_needed_b` (`flag_needed_b`),
  KEY `flag_needed_a` (`flag_needed_a`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=59 ;

--
-- Dumping data for table `wx_template_columns`
--

INSERT INTO `wx_template_columns` (`id`, `wx_template_id`, `name_regex_alias`, `name_table`, `name_column`, `flag_to_raise`, `flag_needed_a`, `flag_needed_b`, `is_ignored`, `rank`, `app_user_id`, `modified_at`) VALUES
(3, 1, 'Data Entry Person', 'propertymain', 'PropertyOwnNumber', 1, NULL, NULL, 1, 1, 1, '2016-09-23 22:03:55'),
(4, 1, 'Property Identifier', 'propertymain', 'PropertyOwnNumber', NULL, NULL, NULL, 0, 2, 1, '2016-09-30 03:34:48'),
(5, 1, 'Property Type', 'propertymain', 'PropertyType', NULL, NULL, NULL, 0, 4, 1, '2016-09-30 03:39:28'),
(6, 1, 'Property Sub-type', 'propertymain', 'PropertySubType', NULL, NULL, NULL, 0, 4.5, 1, '2016-09-30 03:40:14'),
(7, 1, 'Property Street Address', 'propertymain', 'PropertyStreetName', NULL, NULL, NULL, 0, 5, 1, '2016-09-30 03:40:49'),
(8, 1, 'City', 'propertymain', 'PropertyCity', NULL, NULL, NULL, 0, 6, 1, '2016-09-30 03:43:28'),
(9, 1, 'State', 'propertymain', 'PropertyState', NULL, NULL, NULL, 0, 7, 1, '2016-09-30 03:43:29'),
(10, 1, 'Zip', 'propertymain', 'PropertyZipCode', NULL, NULL, NULL, 0, 8, 1, '2016-09-30 03:43:29'),
(11, 1, 'County', 'propertymain', 'PropertyCounty', NULL, NULL, NULL, 0, 9, 1, '2016-09-30 03:43:30'),
(12, 1, 'Country', 'propertymain', 'PropertyCountry', NULL, NULL, NULL, 0, 10, 1, '2016-09-30 03:44:19'),
(13, 1, 'Subdivision', 'propertymain', 'PropertySubDivision', NULL, NULL, NULL, 0, 11, 1, '2016-09-30 03:45:27'),
(14, 1, 'Legal Description', 'propertymain', 'PropertyLegalDescription', NULL, NULL, NULL, 0, 12, 1, '2016-09-30 03:45:28'),
(15, 1, 'GF Number', 'propertygf', 'PropertyGFNumber', NULL, NULL, NULL, 0, 13, 1, '2016-09-30 03:45:28'),
(16, 1, 'Tax ID', 'propertymain', 'PropertyTaxNumber', NULL, NULL, NULL, 0, 3, 1, '2016-09-30 03:45:29'),
(17, 1, 'Geographical Coordinates', 'propertymain', 'PropertyGeographicCodeX', NULL, NULL, NULL, 1, 14, 1, '2016-09-30 03:45:29'),
(18, 1, 'Date of Deed - Transfer', 'propertydeed', 'PropertyDeedDate', NULL, NULL, NULL, 0, 15, 1, '2016-09-30 03:45:29'),
(19, 1, 'Floor Plan', 'propertymain', '', NULL, NULL, NULL, 1, 16, 1, '2016-09-30 03:45:29'),
(20, 1, 'Date Built', 'propertymain', 'PropertyBuiltYear', NULL, NULL, NULL, 0, 17, 1, '2016-09-30 03:45:30'),
(21, 1, 'Type of Construction', 'propertymain', 'PropertyConstructionType', NULL, NULL, NULL, 0, 18, 1, '2016-09-30 03:45:30'),
(22, 1, 'Home Builder', 'homebuilder', 'HomeBuilderName', NULL, NULL, NULL, 0, 19, 1, '2016-09-30 03:58:10'),
(23, 1, 'Home Builder address', 'homebuilder', 'HomeBuilderAddress', NULL, NULL, NULL, 0, 20, 1, '2016-09-30 03:58:10'),
(24, 1, 'Home Builder Telephone', 'homebuilder', 'HomeBuilderPhone', NULL, NULL, NULL, 0, 21, 1, '2016-09-30 03:58:10'),
(25, 1, 'Home Builder Website', 'homebuilder', 'HomeBuilderPhone', NULL, NULL, NULL, 0, 22, 1, '2016-09-30 03:58:11'),
(26, 1, 'Foundation type', 'propertymain', 'PropertyFoundationType', NULL, NULL, NULL, 0, 23, 1, '2016-09-30 03:58:11'),
(27, 1, 'Number of Bedrooms', 'propertymain', 'PropertyNumberOfRoom', NULL, NULL, NULL, 0, 24, 1, '2016-09-30 03:58:11'),
(28, 1, 'Number of Baths', 'propertymain', 'PropertyNumberOfBath', NULL, NULL, NULL, 0, 25, 1, '2016-09-30 03:58:11'),
(29, 1, 'Number of Living Areas', 'propertymain', 'PropertyLivingArea', NULL, NULL, NULL, 0, 26, 1, '2016-09-30 03:58:11'),
(30, 1, 'Garage', 'propertymain', 'PropertyGarage', NULL, NULL, NULL, 0, 27, 1, '2016-09-30 04:17:01'),
(31, 1, 'Covered Patio', 'propertymain', 'PropertyCoveredPatio', NULL, NULL, NULL, 0, 28, 1, '2016-09-30 04:17:02'),
(32, 1, 'Open Patio\\Deck', 'propertymain', 'PropertyOpenPatio', NULL, NULL, NULL, 0, 29, 1, '2016-09-30 04:17:02'),
(33, 1, 'Type of Parking', 'parking', 'ParkingType', 2, NULL, NULL, 0, 30, 1, '2016-09-30 04:17:03'),
(34, 1, 'Subfield - Quantity', 'parking', 'ParkingQty', 2, 2, NULL, 0, 31, 1, '2016-09-30 04:17:39'),
(35, 1, 'Swimming Pool', 'propertymain', 'PropertySwimming', 1, NULL, NULL, 0, 32, 1, '2016-09-30 04:18:15'),
(36, 1, 'Storage building', 'propertymain', '', NULL, NULL, NULL, 1, 33, 1, '2016-09-30 04:18:16'),
(37, 1, 'Miscellaneous', '', NULL, NULL, NULL, NULL, 1, 34, 1, '2016-09-30 04:18:16'),
(38, 1, 'Miscellaneous #2', NULL, NULL, NULL, NULL, NULL, 1, 35, 1, '2016-09-30 04:18:16'),
(39, 1, 'Permits', 'propertypermit', '', NULL, NULL, NULL, 1, 36, 1, '2016-09-30 04:18:17'),
(40, 1, 'Water Source', 'propertymain', 'PropertyWaterSource', NULL, NULL, NULL, 0, 37, 1, '2016-09-30 04:18:17'),
(41, 1, 'Sewer Source', 'propertymain', 'PropertySewerSource', NULL, NULL, NULL, 0, 38, 1, '2016-09-30 04:18:17'),
(42, 1, 'Natural Gas', 'propertymain', 'PropertyHasGas', NULL, NULL, NULL, 0, 39, 1, '2016-09-30 04:18:17'),
(43, 1, 'Propane', 'propertymain', 'PropertyPropane', NULL, NULL, NULL, 0, 40, 1, '2016-09-30 04:18:17'),
(44, 1, 'Electric', 'propertymain', 'PropertyElectricitySource', NULL, NULL, NULL, 0, 41, 1, '2016-09-30 04:19:09'),
(45, 1, 'Survey', 'propertymain', '', NULL, NULL, NULL, 1, 42, 1, '2016-09-30 04:19:10'),
(46, 1, 'Environmental Reports', NULL, NULL, NULL, NULL, NULL, 1, 43, 1, '2016-09-30 04:19:11'),
(47, 1, 'Structural Reports', NULL, NULL, NULL, NULL, NULL, 1, 44, 1, '2016-09-30 04:19:12'),
(48, 1, 'Foundation Reports', NULL, NULL, NULL, NULL, NULL, 1, 45, 1, '2016-09-30 04:19:35'),
(49, 1, 'Easements', NULL, NULL, NULL, NULL, NULL, 1, 46, 1, '2016-09-30 04:19:36'),
(50, 1, 'Wetlands Reports', NULL, NULL, NULL, NULL, NULL, 1, 47, 1, '2016-09-30 04:19:37'),
(51, 1, 'Endangered Species Reports', NULL, NULL, NULL, NULL, NULL, 1, 48, 1, '2016-09-30 04:19:38'),
(52, 1, 'Community Site Plan', NULL, NULL, NULL, NULL, NULL, 1, 49, 1, '2016-09-30 04:19:38'),
(53, 1, 'Mineral Rights Deed\\Leases', 'propertydocuments', '', NULL, NULL, NULL, 0, 50, 1, '2016-09-30 04:19:39'),
(54, 1, 'Leases', NULL, NULL, NULL, NULL, NULL, 0, 51, 1, '2016-09-30 04:20:28'),
(55, 1, 'Miscellaneous Activity Field', 'propertyactivity', 'PropertyActivityDescription', NULL, NULL, NULL, 0, 52, 1, '2016-09-30 04:20:28'),
(57, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, '2016-10-08 05:01:06'),
(58, 5, 'sample pattern', 'pricecomparison', 'PriceComparisonCompany', 2, NULL, NULL, 1, 1, 1, '2016-10-08 06:48:40');

-- --------------------------------------------------------

--
-- Table structure for table `wx_template_errors`
--

CREATE TABLE IF NOT EXISTS `wx_template_errors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wx_batch_id` int(11) NOT NULL,
  `type_error` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'conflict,not_found',
  `dbf_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `is_hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `wx_batch_id` (`wx_batch_id`),
  KEY `type_error` (`type_error`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='errors formed when an upload is processed by a batch' AUTO_INCREMENT=983 ;

--
-- Dumping data for table `wx_template_errors`
--

INSERT INTO `wx_template_errors` (`id`, `wx_batch_id`, `type_error`, `dbf_key`, `message`, `notes`, `is_hidden`) VALUES
(1, 3, 'not_found', 'Data Entry Person\\Source Code', '', '', 0),
(2, 3, 'not_found', 'Property Identifier - Permanent', '', '', 0),
(3, 3, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(4, 3, 'not_found', 'Property Type', '', '', 0),
(5, 3, 'not_found', 'Property Sub-type', '', '', 0),
(6, 3, 'not_found', 'Property Street Address', '', '', 0),
(7, 3, 'not_found', 'Property Address #2', '', '', 0),
(8, 3, 'not_found', 'Property Address #3', '', '', 0),
(9, 3, 'not_found', 'Property City', '', '', 0),
(10, 3, 'not_found', 'Property State', '', '', 0),
(11, 3, 'not_found', 'Property Zip code', '', '', 0),
(12, 3, 'not_found', 'Property County', '', '', 0),
(13, 3, 'not_found', 'Property Country', '', '', 0),
(14, 3, 'not_found', 'Property Subdivision', '', '', 0),
(15, 3, 'not_found', 'Legal Description', '', '', 0),
(16, 3, 'not_found', 'GF Number', '', '', 0),
(17, 3, 'not_found', 'Tax ID - Account Number', '', '', 0),
(18, 3, 'not_found', 'Geographical Coordinates', '', '', 0),
(19, 3, 'not_found', 'Date of Deed - Transfer', '', '', 0),
(20, 3, 'not_found', 'Floor Plan', '', '', 0),
(21, 3, 'not_found', 'Date Built', '', '', 0),
(22, 3, 'not_found', 'Type of Construction', '', '', 0),
(23, 3, 'not_found', 'Home Builder', '', '', 0),
(24, 3, 'not_found', 'Home Builder address', '', '', 0),
(25, 3, 'not_found', 'Home Builder Telephone', '', '', 0),
(26, 3, 'not_found', 'Home Builder Website', '', '', 0),
(27, 3, 'not_found', 'Foundation type', '', '', 0),
(28, 3, 'not_found', 'Number of Bedrooms', '', '', 0),
(29, 3, 'not_found', 'Number of Baths', '', '', 0),
(30, 3, 'not_found', 'Number of Living Areas', '', '', 0),
(31, 3, 'not_found', 'Garage', '', '', 0),
(32, 3, 'not_found', 'Covered Patio', '', '', 0),
(33, 3, 'not_found', 'Open Patio\\Deck', '', '', 0),
(34, 3, 'not_found', 'Type of Parking', '', '', 0),
(35, 3, 'not_found', 'Subfield - Quantity', '', '', 0),
(36, 3, 'not_found', 'Swimming Pool', '', '', 0),
(37, 3, 'not_found', 'Storage building', '', '', 0),
(38, 3, 'not_found', 'Miscellaneous', '', '', 0),
(39, 3, 'not_found', 'Miscellaneous #2', '', '', 0),
(40, 3, 'not_found', 'Permits', '', '', 0),
(41, 3, 'not_found', 'Water Source', '', '', 0),
(42, 3, 'not_found', 'Sewer Source', '', '', 0),
(43, 3, 'not_found', 'Natural Gas', '', '', 0),
(44, 3, 'not_found', 'Propane', '', '', 0),
(45, 3, 'not_found', 'Electric', '', '', 0),
(46, 3, 'not_found', 'Survey', '', '', 0),
(47, 3, 'not_found', 'Environmental Reports', '', '', 0),
(48, 3, 'not_found', 'Structural Reports', '', '', 0),
(49, 3, 'not_found', 'Foundation Reports', '', '', 0),
(50, 3, 'not_found', 'Easements', '', '', 0),
(51, 3, 'not_found', 'Wetlands Reports', '', '', 0),
(52, 3, 'not_found', 'Endangered Species Reports', '', '', 0),
(53, 3, 'not_found', 'Community Site Plan', '', '', 0),
(54, 3, 'not_found', 'Warranty', '', '', 0),
(55, 3, 'not_found', 'Mineral Rights Deed\\Leases', '', '', 0),
(56, 3, 'not_found', 'Leases', '', '', 0),
(57, 3, 'not_found', 'Miscellaneous Activity Field #1', '', '', 0),
(58, 3, 'not_found', 'Miscellaneous Activity Field #2', '', '', 0),
(59, 3, 'not_found', 'Miscellaneous Activity Field #3', '', '', 0),
(60, 3, 'not_found', 'Miscellaneous Activity Field #4', '', '', 0),
(61, 3, 'not_found', 'Miscellaneous Activity Field #5', '', '', 0),
(62, 3, 'not_found', 'Garage Door(s)', '', '', 0),
(63, 3, 'not_found', 'Contractor', '', '', 0),
(64, 3, 'not_found', 'Contractor address', '', '', 0),
(65, 3, 'not_found', 'Contractor phone number', '', '', 0),
(66, 3, 'not_found', 'Quantity', '', '', 0),
(67, 3, 'not_found', 'Door Manufacturer', '', '', 0),
(68, 3, 'not_found', 'Door Model Number', '', '', 0),
(69, 3, 'not_found', 'Date installed', '', '', 0),
(70, 3, 'not_found', 'Garage Opener', '', '', 0),
(71, 3, 'not_found', 'System Manufacturer', '', '', 0),
(72, 3, 'not_found', 'System Model Number', '', '', 0),
(73, 3, 'not_found', 'Alarm System', '', '', 0),
(74, 3, 'not_found', 'Foundation', '', '', 0),
(75, 3, 'not_found', 'Type', '', '', 0),
(76, 3, 'not_found', 'Windows', '', '', 0),
(77, 3, 'not_found', 'Manufacturer', '', '', 0),
(78, 3, 'not_found', 'Manufacturer address', '', '', 0),
(79, 3, 'not_found', 'Manufacturer phone number', '', '', 0),
(80, 3, 'not_found', 'Manufacturer website', '', '', 0),
(81, 3, 'not_found', 'Model', '', '', 0),
(82, 3, 'not_found', 'HVAC', '', '', 0),
(83, 3, 'not_found', 'Furnace Manufacturer', '', '', 0),
(84, 3, 'not_found', 'Furnace Model Numbers', '', '', 0),
(85, 3, 'not_found', 'Condenser Manufacturer', '', '', 0),
(86, 3, 'not_found', 'Condenser Model Number', '', '', 0),
(87, 3, 'not_found', 'Date Installed', '', '', 0),
(88, 3, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(89, 3, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(90, 3, 'not_found', 'Electrical', '', '', 0),
(91, 3, 'not_found', 'Emergency Generator', '', '', 0),
(92, 3, 'not_found', 'Model Numbers', '', '', 0),
(93, 3, 'not_found', 'Septic System', '', '', 0),
(94, 3, 'not_found', 'Water Well System', '', '', 0),
(95, 3, 'not_found', 'Irrigation System', '', '', 0),
(96, 3, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(97, 3, 'not_found', 'Sauna', '', '', 0),
(98, 3, 'not_found', 'Plumbing Contractor', '', '', 0),
(99, 3, 'not_found', 'Finish', '', '', 0),
(100, 3, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(101, 3, 'not_found', 'Appliances', '', '', 0),
(102, 3, 'not_found', 'Painting', '', '', 0),
(103, 3, 'not_found', 'Date work done', '', '', 0),
(104, 3, 'not_found', 'Walls', '', '', 0),
(105, 3, 'not_found', 'Brand', '', '', 0),
(106, 3, 'not_found', 'Color', '', '', 0),
(107, 3, 'not_found', 'Ceilings', '', '', 0),
(108, 3, 'not_found', 'Doors and Trim', '', '', 0),
(109, 3, 'not_found', 'Closet', '', '', 0),
(110, 3, 'not_found', 'Bathrooms', '', '', 0),
(111, 3, 'not_found', 'Cabinets', '', '', 0),
(112, 3, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(113, 3, 'not_found', 'Exterior Trim', '', '', 0),
(114, 3, 'not_found', 'Exterior Garage Doors', '', '', 0),
(115, 3, 'not_found', 'Exterior Front Door', '', '', 0),
(116, 3, 'not_found', 'Miscellaneous #1', '', '', 0),
(117, 3, 'not_found', 'Miscellaneous #3', '', '', 0),
(118, 3, 'not_found', 'Miscellaneous #4', '', '', 0),
(119, 3, 'not_found', 'Miscellaneous #5', '', '', 0),
(120, 3, 'not_found', 'Exterior Walls', '', '', 0),
(121, 3, 'not_found', 'Brick manufacturer', '', '', 0),
(122, 3, 'not_found', 'Siding', '', '', 0),
(123, 3, 'not_found', 'Stone', '', '', 0),
(124, 3, 'not_found', 'Kitchen Cabinets', '', '', 0),
(125, 3, 'not_found', 'Finish Type', '', '', 0),
(126, 3, 'not_found', 'Kitchen Countertop', '', '', 0),
(127, 3, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(128, 3, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(129, 3, 'not_found', 'Powder Room Countertop', '', '', 0),
(130, 3, 'not_found', 'Powder Room Cabinets', '', '', 0),
(131, 3, 'not_found', 'Bath #2 Countertop', '', '', 0),
(132, 3, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(133, 3, 'not_found', 'Fireplace #1', '', '', 0),
(134, 3, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(135, 3, 'not_found', 'Surround Type', '', '', 0),
(136, 3, 'not_found', 'Surround Finish', '', '', 0),
(137, 3, 'not_found', 'Surround Color', '', '', 0),
(138, 3, 'not_found', 'Surround Brand', '', '', 0),
(139, 3, 'not_found', 'Surround Manufacturer', '', '', 0),
(140, 3, 'not_found', 'Hearth Type', '', '', 0),
(141, 3, 'not_found', 'Hearth Finish', '', '', 0),
(142, 3, 'not_found', 'Hearth Color', '', '', 0),
(143, 3, 'not_found', 'Hearth Brand', '', '', 0),
(144, 3, 'not_found', 'Hearth Manufacturer', '', '', 0),
(145, 3, 'not_found', 'Living Room', '', '', 0),
(146, 3, 'not_found', 'Flooring Type', '', '', 0),
(147, 3, 'not_found', 'Wall Paint', '', '', 0),
(148, 3, 'not_found', 'Accent Wall Paint', '', '', 0),
(149, 3, 'not_found', 'Ceiling Paint', '', '', 0),
(150, 3, 'not_found', 'Doors and Trim Paint', '', '', 0),
(151, 3, 'not_found', 'Kitchen', '', '', 0),
(152, 3, 'not_found', 'Family Room', '', '', 0),
(153, 3, 'not_found', 'Dining Room', '', '', 0),
(154, 3, 'not_found', 'Breakfast Room', '', '', 0),
(155, 3, 'not_found', 'Game Room', '', '', 0),
(156, 3, 'not_found', 'Master Bedroom', '', '', 0),
(157, 3, 'not_found', 'Bedroom #2', '', '', 0),
(158, 3, 'not_found', 'Bedroom #3', '', '', 0),
(159, 3, 'not_found', 'Bedroom #4', '', '', 0),
(160, 3, 'not_found', 'Utility Room', '', '', 0),
(161, 3, 'not_found', 'Master Bathroom', '', '', 0),
(162, 3, 'not_found', 'Wall Tile', '', '', 0),
(163, 3, 'not_found', '2nd Bathroom', '', '', 0),
(164, 3, 'not_found', 'Powder Room', '', '', 0),
(165, 10, 'not_found', 'Data Entry Person\\Source Code', '', '', 0),
(166, 10, 'not_found', 'Property Identifier - Permanent', '', '', 0),
(167, 10, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(168, 10, 'not_found', 'Property Type', '', '', 0),
(169, 10, 'not_found', 'Property Sub-type', '', '', 0),
(170, 10, 'not_found', 'Property Street Address', '', '', 0),
(171, 10, 'not_found', 'Property Address #2', '', '', 0),
(172, 10, 'not_found', 'Property Address #3', '', '', 0),
(173, 10, 'not_found', 'Property City', '', '', 0),
(174, 10, 'not_found', 'Property State', '', '', 0),
(175, 10, 'not_found', 'Property Zip code', '', '', 0),
(176, 10, 'not_found', 'Property County', '', '', 0),
(177, 10, 'not_found', 'Property Country', '', '', 0),
(178, 10, 'not_found', 'Property Subdivision', '', '', 0),
(179, 10, 'not_found', 'Legal Description', '', '', 0),
(180, 10, 'not_found', 'GF Number', '', '', 0),
(181, 10, 'not_found', 'Tax ID - Account Number', '', '', 0),
(182, 10, 'not_found', 'Geographical Coordinates', '', '', 0),
(183, 10, 'not_found', 'Date of Deed - Transfer', '', '', 0),
(184, 10, 'not_found', 'Floor Plan', '', '', 0),
(185, 10, 'not_found', 'Date Built', '', '', 0),
(186, 10, 'not_found', 'Type of Construction', '', '', 0),
(187, 10, 'not_found', 'Home Builder', '', '', 0),
(188, 10, 'not_found', 'Home Builder address', '', '', 0),
(189, 10, 'not_found', 'Home Builder Telephone', '', '', 0),
(190, 10, 'not_found', 'Home Builder Website', '', '', 0),
(191, 10, 'not_found', 'Foundation type', '', '', 0),
(192, 10, 'not_found', 'Number of Bedrooms', '', '', 0),
(193, 10, 'not_found', 'Number of Baths', '', '', 0),
(194, 10, 'not_found', 'Number of Living Areas', '', '', 0),
(195, 10, 'not_found', 'Garage', '', '', 0),
(196, 10, 'not_found', 'Covered Patio', '', '', 0),
(197, 10, 'not_found', 'Open Patio\\Deck', '', '', 0),
(198, 10, 'not_found', 'Type of Parking', '', '', 0),
(199, 10, 'not_found', 'Subfield - Quantity', '', '', 0),
(200, 10, 'not_found', 'Swimming Pool', '', '', 0),
(201, 10, 'not_found', 'Storage building', '', '', 0),
(202, 10, 'not_found', 'Miscellaneous', '', '', 0),
(203, 10, 'not_found', 'Miscellaneous #2', '', '', 0),
(204, 10, 'not_found', 'Permits', '', '', 0),
(205, 10, 'not_found', 'Water Source', '', '', 0),
(206, 10, 'not_found', 'Sewer Source', '', '', 0),
(207, 10, 'not_found', 'Natural Gas', '', '', 0),
(208, 10, 'not_found', 'Propane', '', '', 0),
(209, 10, 'not_found', 'Electric', '', '', 0),
(210, 10, 'not_found', 'Survey', '', '', 0),
(211, 10, 'not_found', 'Environmental Reports', '', '', 0),
(212, 10, 'not_found', 'Structural Reports', '', '', 0),
(213, 10, 'not_found', 'Foundation Reports', '', '', 0),
(214, 10, 'not_found', 'Easements', '', '', 0),
(215, 10, 'not_found', 'Wetlands Reports', '', '', 0),
(216, 10, 'not_found', 'Endangered Species Reports', '', '', 0),
(217, 10, 'not_found', 'Community Site Plan', '', '', 0),
(218, 10, 'not_found', 'Warranty', '', '', 0),
(219, 10, 'not_found', 'Mineral Rights Deed\\Leases', '', '', 0),
(220, 10, 'not_found', 'Leases', '', '', 0),
(221, 10, 'not_found', 'Miscellaneous Activity Field #1', '', '', 0),
(222, 10, 'not_found', 'Miscellaneous Activity Field #2', '', '', 0),
(223, 10, 'not_found', 'Miscellaneous Activity Field #3', '', '', 0),
(224, 10, 'not_found', 'Miscellaneous Activity Field #4', '', '', 0),
(225, 10, 'not_found', 'Miscellaneous Activity Field #5', '', '', 0),
(226, 10, 'not_found', 'Garage Door(s)', '', '', 0),
(227, 10, 'not_found', 'Contractor', '', '', 0),
(228, 10, 'not_found', 'Contractor address', '', '', 0),
(229, 10, 'not_found', 'Contractor phone number', '', '', 0),
(230, 10, 'not_found', 'Quantity', '', '', 0),
(231, 10, 'not_found', 'Door Manufacturer', '', '', 0),
(232, 10, 'not_found', 'Door Model Number', '', '', 0),
(233, 10, 'not_found', 'Date installed', '', '', 0),
(234, 10, 'not_found', 'Garage Opener', '', '', 0),
(235, 10, 'not_found', 'System Manufacturer', '', '', 0),
(236, 10, 'not_found', 'System Model Number', '', '', 0),
(237, 10, 'not_found', 'Alarm System', '', '', 0),
(238, 10, 'not_found', 'Foundation', '', '', 0),
(239, 10, 'not_found', 'Type', '', '', 0),
(240, 10, 'not_found', 'Windows', '', '', 0),
(241, 10, 'not_found', 'Manufacturer', '', '', 0),
(242, 10, 'not_found', 'Manufacturer address', '', '', 0),
(243, 10, 'not_found', 'Manufacturer phone number', '', '', 0),
(244, 10, 'not_found', 'Manufacturer website', '', '', 0),
(245, 10, 'not_found', 'Model', '', '', 0),
(246, 10, 'not_found', 'HVAC', '', '', 0),
(247, 10, 'not_found', 'Furnace Manufacturer', '', '', 0),
(248, 10, 'not_found', 'Furnace Model Numbers', '', '', 0),
(249, 10, 'not_found', 'Condenser Manufacturer', '', '', 0),
(250, 10, 'not_found', 'Condenser Model Number', '', '', 0),
(251, 10, 'not_found', 'Date Installed', '', '', 0),
(252, 10, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(253, 10, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(254, 10, 'not_found', 'Electrical', '', '', 0),
(255, 10, 'not_found', 'Emergency Generator', '', '', 0),
(256, 10, 'not_found', 'Model Numbers', '', '', 0),
(257, 10, 'not_found', 'Septic System', '', '', 0),
(258, 10, 'not_found', 'Water Well System', '', '', 0),
(259, 10, 'not_found', 'Irrigation System', '', '', 0),
(260, 10, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(261, 10, 'not_found', 'Sauna', '', '', 0),
(262, 10, 'not_found', 'Plumbing Contractor', '', '', 0),
(263, 10, 'not_found', 'Finish', '', '', 0),
(264, 10, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(265, 10, 'not_found', 'Appliances', '', '', 0),
(266, 10, 'not_found', 'Painting', '', '', 0),
(267, 10, 'not_found', 'Date work done', '', '', 0),
(268, 10, 'not_found', 'Walls', '', '', 0),
(269, 10, 'not_found', 'Brand', '', '', 0),
(270, 10, 'not_found', 'Color', '', '', 0),
(271, 10, 'not_found', 'Ceilings', '', '', 0),
(272, 10, 'not_found', 'Doors and Trim', '', '', 0),
(273, 10, 'not_found', 'Closet', '', '', 0),
(274, 10, 'not_found', 'Bathrooms', '', '', 0),
(275, 10, 'not_found', 'Cabinets', '', '', 0),
(276, 10, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(277, 10, 'not_found', 'Exterior Trim', '', '', 0),
(278, 10, 'not_found', 'Exterior Garage Doors', '', '', 0),
(279, 10, 'not_found', 'Exterior Front Door', '', '', 0),
(280, 10, 'not_found', 'Miscellaneous #1', '', '', 0),
(281, 10, 'not_found', 'Miscellaneous #3', '', '', 0),
(282, 10, 'not_found', 'Miscellaneous #4', '', '', 0),
(283, 10, 'not_found', 'Miscellaneous #5', '', '', 0),
(284, 10, 'not_found', 'Exterior Walls', '', '', 0),
(285, 10, 'not_found', 'Brick manufacturer', '', '', 0),
(286, 10, 'not_found', 'Siding', '', '', 0),
(287, 10, 'not_found', 'Stone', '', '', 0),
(288, 10, 'not_found', 'Kitchen Cabinets', '', '', 0),
(289, 10, 'not_found', 'Finish Type', '', '', 0),
(290, 10, 'not_found', 'Kitchen Countertop', '', '', 0),
(291, 10, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(292, 10, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(293, 10, 'not_found', 'Powder Room Countertop', '', '', 0),
(294, 10, 'not_found', 'Powder Room Cabinets', '', '', 0),
(295, 10, 'not_found', 'Bath #2 Countertop', '', '', 0),
(296, 10, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(297, 10, 'not_found', 'Fireplace #1', '', '', 0),
(298, 10, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(299, 10, 'not_found', 'Surround Type', '', '', 0),
(300, 10, 'not_found', 'Surround Finish', '', '', 0),
(301, 10, 'not_found', 'Surround Color', '', '', 0),
(302, 10, 'not_found', 'Surround Brand', '', '', 0),
(303, 10, 'not_found', 'Surround Manufacturer', '', '', 0),
(304, 10, 'not_found', 'Hearth Type', '', '', 0),
(305, 10, 'not_found', 'Hearth Finish', '', '', 0),
(306, 10, 'not_found', 'Hearth Color', '', '', 0),
(307, 10, 'not_found', 'Hearth Brand', '', '', 0),
(308, 10, 'not_found', 'Hearth Manufacturer', '', '', 0),
(309, 10, 'not_found', 'Living Room', '', '', 0),
(310, 10, 'not_found', 'Flooring Type', '', '', 0),
(311, 10, 'not_found', 'Wall Paint', '', '', 0),
(312, 10, 'not_found', 'Accent Wall Paint', '', '', 0),
(313, 10, 'not_found', 'Ceiling Paint', '', '', 0),
(314, 10, 'not_found', 'Doors and Trim Paint', '', '', 0),
(315, 10, 'not_found', 'Kitchen', '', '', 0),
(316, 10, 'not_found', 'Family Room', '', '', 0),
(317, 10, 'not_found', 'Dining Room', '', '', 0),
(318, 10, 'not_found', 'Breakfast Room', '', '', 0),
(319, 10, 'not_found', 'Game Room', '', '', 0),
(320, 10, 'not_found', 'Master Bedroom', '', '', 0),
(321, 10, 'not_found', 'Bedroom #2', '', '', 0),
(322, 10, 'not_found', 'Bedroom #3', '', '', 0),
(323, 10, 'not_found', 'Bedroom #4', '', '', 0),
(324, 10, 'not_found', 'Utility Room', '', '', 0),
(325, 10, 'not_found', 'Master Bathroom', '', '', 0),
(326, 10, 'not_found', 'Wall Tile', '', '', 0),
(327, 10, 'not_found', '2nd Bathroom', '', '', 0),
(328, 10, 'not_found', 'Powder Room', '', '', 0),
(329, 37, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(330, 37, 'not_found', 'Property Address #2', '', '', 0),
(331, 37, 'not_found', 'Property Address #3', '', '', 0),
(332, 37, 'conflict', 'Home Builder address', '22,23', '', 0),
(333, 37, 'conflict', 'Home Builder Telephone', '22,24', '', 0),
(334, 37, 'conflict', 'Home Builder Website', '22,25', '', 0),
(335, 37, 'conflict', 'Miscellaneous #2', '37,38', '', 0),
(336, 37, 'not_found', 'Warranty', '', '', 0),
(337, 37, 'conflict', 'Mineral Rights Deed\\Leases', '53,54', '', 0),
(338, 37, 'conflict', 'Miscellaneous Activity Field #1', '37,55', '', 0),
(339, 37, 'conflict', 'Miscellaneous Activity Field #2', '37,55', '', 0),
(340, 37, 'conflict', 'Miscellaneous Activity Field #3', '37,55', '', 0),
(341, 37, 'conflict', 'Miscellaneous Activity Field #4', '37,55', '', 0),
(342, 37, 'conflict', 'Miscellaneous Activity Field #5', '37,55', '', 0),
(343, 37, 'not_found', 'Contractor', '', '', 0),
(344, 37, 'not_found', 'Contractor address', '', '', 0),
(345, 37, 'not_found', 'Contractor phone number', '', '', 0),
(346, 37, 'not_found', 'Quantity', '', '', 0),
(347, 37, 'not_found', 'Door Manufacturer', '', '', 0),
(348, 37, 'not_found', 'Door Model Number', '', '', 0),
(349, 37, 'not_found', 'Date installed', '', '', 0),
(350, 37, 'not_found', 'System Manufacturer', '', '', 0),
(351, 37, 'not_found', 'System Model Number', '', '', 0),
(352, 37, 'not_found', 'Alarm System', '', '', 0),
(353, 37, 'not_found', 'Foundation', '', '', 0),
(354, 37, 'not_found', 'Type', '', '', 0),
(355, 37, 'not_found', 'Windows', '', '', 0),
(356, 37, 'not_found', 'Manufacturer', '', '', 0),
(357, 37, 'not_found', 'Manufacturer address', '', '', 0),
(358, 37, 'not_found', 'Manufacturer phone number', '', '', 0),
(359, 37, 'not_found', 'Manufacturer website', '', '', 0),
(360, 37, 'not_found', 'Model', '', '', 0),
(361, 37, 'not_found', 'HVAC', '', '', 0),
(362, 37, 'not_found', 'Furnace Manufacturer', '', '', 0),
(363, 37, 'not_found', 'Furnace Model Numbers', '', '', 0),
(364, 37, 'not_found', 'Condenser Manufacturer', '', '', 0),
(365, 37, 'not_found', 'Condenser Model Number', '', '', 0),
(366, 37, 'not_found', 'Date Installed', '', '', 0),
(367, 37, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(368, 37, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(369, 37, 'not_found', 'Emergency Generator', '', '', 0),
(370, 37, 'not_found', 'Model Numbers', '', '', 0),
(371, 37, 'not_found', 'Septic System', '', '', 0),
(372, 37, 'not_found', 'Water Well System', '', '', 0),
(373, 37, 'not_found', 'Irrigation System', '', '', 0),
(374, 37, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(375, 37, 'not_found', 'Sauna', '', '', 0),
(376, 37, 'not_found', 'Plumbing Contractor', '', '', 0),
(377, 37, 'not_found', 'Finish', '', '', 0),
(378, 37, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(379, 37, 'not_found', 'Appliances', '', '', 0),
(380, 37, 'not_found', 'Painting', '', '', 0),
(381, 37, 'not_found', 'Date work done', '', '', 0),
(382, 37, 'not_found', 'Walls', '', '', 0),
(383, 37, 'not_found', 'Brand', '', '', 0),
(384, 37, 'not_found', 'Color', '', '', 0),
(385, 37, 'not_found', 'Ceilings', '', '', 0),
(386, 37, 'not_found', 'Doors and Trim', '', '', 0),
(387, 37, 'not_found', 'Closet', '', '', 0),
(388, 37, 'not_found', 'Bathrooms', '', '', 0),
(389, 37, 'not_found', 'Cabinets', '', '', 0),
(390, 37, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(391, 37, 'not_found', 'Exterior Trim', '', '', 0),
(392, 37, 'not_found', 'Exterior Front Door', '', '', 0),
(393, 37, 'not_found', 'Exterior Walls', '', '', 0),
(394, 37, 'not_found', 'Brick manufacturer', '', '', 0),
(395, 37, 'not_found', 'Siding', '', '', 0),
(396, 37, 'not_found', 'Stone', '', '', 0),
(397, 37, 'not_found', 'Kitchen Cabinets', '', '', 0),
(398, 37, 'not_found', 'Finish Type', '', '', 0),
(399, 37, 'not_found', 'Kitchen Countertop', '', '', 0),
(400, 37, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(401, 37, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(402, 37, 'not_found', 'Powder Room Countertop', '', '', 0),
(403, 37, 'not_found', 'Powder Room Cabinets', '', '', 0),
(404, 37, 'not_found', 'Bath #2 Countertop', '', '', 0),
(405, 37, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(406, 37, 'not_found', 'Fireplace #1', '', '', 0),
(407, 37, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(408, 37, 'not_found', 'Surround Type', '', '', 0),
(409, 37, 'not_found', 'Surround Finish', '', '', 0),
(410, 37, 'not_found', 'Surround Color', '', '', 0),
(411, 37, 'not_found', 'Surround Brand', '', '', 0),
(412, 37, 'not_found', 'Surround Manufacturer', '', '', 0),
(413, 37, 'not_found', 'Hearth Type', '', '', 0),
(414, 37, 'not_found', 'Hearth Finish', '', '', 0),
(415, 37, 'not_found', 'Hearth Color', '', '', 0),
(416, 37, 'not_found', 'Hearth Brand', '', '', 0),
(417, 37, 'not_found', 'Hearth Manufacturer', '', '', 0),
(418, 37, 'not_found', 'Living Room', '', '', 0),
(419, 37, 'not_found', 'Flooring Type', '', '', 0),
(420, 37, 'not_found', 'Wall Paint', '', '', 0),
(421, 37, 'not_found', 'Accent Wall Paint', '', '', 0),
(422, 37, 'not_found', 'Ceiling Paint', '', '', 0),
(423, 37, 'not_found', 'Doors and Trim Paint', '', '', 0),
(424, 37, 'not_found', 'Kitchen', '', '', 0),
(425, 37, 'not_found', 'Family Room', '', '', 0),
(426, 37, 'not_found', 'Dining Room', '', '', 0),
(427, 37, 'not_found', 'Breakfast Room', '', '', 0),
(428, 37, 'not_found', 'Game Room', '', '', 0),
(429, 37, 'not_found', 'Master Bedroom', '', '', 0),
(430, 37, 'not_found', 'Bedroom #2', '', '', 0),
(431, 37, 'not_found', 'Bedroom #3', '', '', 0),
(432, 37, 'not_found', 'Bedroom #4', '', '', 0),
(433, 37, 'not_found', 'Utility Room', '', '', 0),
(434, 37, 'not_found', 'Master Bathroom', '', '', 0),
(435, 37, 'not_found', 'Wall Tile', '', '', 0),
(436, 37, 'not_found', '2nd Bathroom', '', '', 0),
(437, 37, 'not_found', 'Powder Room', '', '', 0),
(438, 39, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(439, 39, 'not_found', 'Property Address #2', '', '', 0),
(440, 39, 'not_found', 'Property Address #3', '', '', 0),
(441, 39, 'conflict', 'Home Builder address', '22,23', '', 0),
(442, 39, 'conflict', 'Home Builder Telephone', '22,24', '', 0),
(443, 39, 'conflict', 'Home Builder Website', '22,25', '', 0),
(444, 39, 'conflict', 'Miscellaneous #2', '37,38', '', 0),
(445, 39, 'not_found', 'Warranty', '', '', 0),
(446, 39, 'conflict', 'Mineral Rights Deed\\Leases', '53,54', '', 0),
(447, 39, 'conflict', 'Miscellaneous Activity Field #1', '37,55', '', 0),
(448, 39, 'conflict', 'Miscellaneous Activity Field #2', '37,55', '', 0),
(449, 39, 'conflict', 'Miscellaneous Activity Field #3', '37,55', '', 0),
(450, 39, 'conflict', 'Miscellaneous Activity Field #4', '37,55', '', 0),
(451, 39, 'conflict', 'Miscellaneous Activity Field #5', '37,55', '', 0),
(452, 39, 'not_found', 'Contractor', '', '', 0),
(453, 39, 'not_found', 'Contractor address', '', '', 0),
(454, 39, 'not_found', 'Contractor phone number', '', '', 0),
(455, 39, 'not_found', 'Quantity', '', '', 0),
(456, 39, 'not_found', 'Door Manufacturer', '', '', 0),
(457, 39, 'not_found', 'Door Model Number', '', '', 0),
(458, 39, 'not_found', 'Date installed', '', '', 0),
(459, 39, 'not_found', 'System Manufacturer', '', '', 0),
(460, 39, 'not_found', 'System Model Number', '', '', 0),
(461, 39, 'not_found', 'Alarm System', '', '', 0),
(462, 39, 'not_found', 'Foundation', '', '', 0),
(463, 39, 'not_found', 'Type', '', '', 0),
(464, 39, 'not_found', 'Windows', '', '', 0),
(465, 39, 'not_found', 'Manufacturer', '', '', 0),
(466, 39, 'not_found', 'Manufacturer address', '', '', 0),
(467, 39, 'not_found', 'Manufacturer phone number', '', '', 0),
(468, 39, 'not_found', 'Manufacturer website', '', '', 0),
(469, 39, 'not_found', 'Model', '', '', 0),
(470, 39, 'not_found', 'HVAC', '', '', 0),
(471, 39, 'not_found', 'Furnace Manufacturer', '', '', 0),
(472, 39, 'not_found', 'Furnace Model Numbers', '', '', 0),
(473, 39, 'not_found', 'Condenser Manufacturer', '', '', 0),
(474, 39, 'not_found', 'Condenser Model Number', '', '', 0),
(475, 39, 'not_found', 'Date Installed', '', '', 0),
(476, 39, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(477, 39, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(478, 39, 'not_found', 'Emergency Generator', '', '', 0),
(479, 39, 'not_found', 'Model Numbers', '', '', 0),
(480, 39, 'not_found', 'Septic System', '', '', 0),
(481, 39, 'not_found', 'Water Well System', '', '', 0),
(482, 39, 'not_found', 'Irrigation System', '', '', 0),
(483, 39, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(484, 39, 'not_found', 'Sauna', '', '', 0),
(485, 39, 'not_found', 'Plumbing Contractor', '', '', 0),
(486, 39, 'not_found', 'Finish', '', '', 0),
(487, 39, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(488, 39, 'not_found', 'Appliances', '', '', 0),
(489, 39, 'not_found', 'Painting', '', '', 0),
(490, 39, 'not_found', 'Date work done', '', '', 0),
(491, 39, 'not_found', 'Walls', '', '', 0),
(492, 39, 'not_found', 'Brand', '', '', 0),
(493, 39, 'not_found', 'Color', '', '', 0),
(494, 39, 'not_found', 'Ceilings', '', '', 0),
(495, 39, 'not_found', 'Doors and Trim', '', '', 0),
(496, 39, 'not_found', 'Closet', '', '', 0),
(497, 39, 'not_found', 'Bathrooms', '', '', 0),
(498, 39, 'not_found', 'Cabinets', '', '', 0),
(499, 39, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(500, 39, 'not_found', 'Exterior Trim', '', '', 0),
(501, 39, 'not_found', 'Exterior Front Door', '', '', 0),
(502, 39, 'not_found', 'Exterior Walls', '', '', 0),
(503, 39, 'not_found', 'Brick manufacturer', '', '', 0),
(504, 39, 'not_found', 'Siding', '', '', 0),
(505, 39, 'not_found', 'Stone', '', '', 0),
(506, 39, 'not_found', 'Kitchen Cabinets', '', '', 0),
(507, 39, 'not_found', 'Finish Type', '', '', 0),
(508, 39, 'not_found', 'Kitchen Countertop', '', '', 0),
(509, 39, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(510, 39, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(511, 39, 'not_found', 'Powder Room Countertop', '', '', 0),
(512, 39, 'not_found', 'Powder Room Cabinets', '', '', 0),
(513, 39, 'not_found', 'Bath #2 Countertop', '', '', 0),
(514, 39, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(515, 39, 'not_found', 'Fireplace #1', '', '', 0),
(516, 39, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(517, 39, 'not_found', 'Surround Type', '', '', 0),
(518, 39, 'not_found', 'Surround Finish', '', '', 0),
(519, 39, 'not_found', 'Surround Color', '', '', 0),
(520, 39, 'not_found', 'Surround Brand', '', '', 0),
(521, 39, 'not_found', 'Surround Manufacturer', '', '', 0),
(522, 39, 'not_found', 'Hearth Type', '', '', 0),
(523, 39, 'not_found', 'Hearth Finish', '', '', 0),
(524, 39, 'not_found', 'Hearth Color', '', '', 0),
(525, 39, 'not_found', 'Hearth Brand', '', '', 0),
(526, 39, 'not_found', 'Hearth Manufacturer', '', '', 0),
(527, 39, 'not_found', 'Living Room', '', '', 0),
(528, 39, 'not_found', 'Flooring Type', '', '', 0),
(529, 39, 'not_found', 'Wall Paint', '', '', 0),
(530, 39, 'not_found', 'Accent Wall Paint', '', '', 0),
(531, 39, 'not_found', 'Ceiling Paint', '', '', 0),
(532, 39, 'not_found', 'Doors and Trim Paint', '', '', 0),
(533, 39, 'not_found', 'Kitchen', '', '', 0),
(534, 39, 'not_found', 'Family Room', '', '', 0),
(535, 39, 'not_found', 'Dining Room', '', '', 0),
(536, 39, 'not_found', 'Breakfast Room', '', '', 0),
(537, 39, 'not_found', 'Game Room', '', '', 0),
(538, 39, 'not_found', 'Master Bedroom', '', '', 0),
(539, 39, 'not_found', 'Bedroom #2', '', '', 0),
(540, 39, 'not_found', 'Bedroom #3', '', '', 0),
(541, 39, 'not_found', 'Bedroom #4', '', '', 0),
(542, 39, 'not_found', 'Utility Room', '', '', 0),
(543, 39, 'not_found', 'Master Bathroom', '', '', 0),
(544, 39, 'not_found', 'Wall Tile', '', '', 0),
(545, 39, 'not_found', '2nd Bathroom', '', '', 0),
(546, 39, 'not_found', 'Powder Room', '', '', 0),
(547, 40, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(548, 40, 'not_found', 'Property Address #2', '', '', 0),
(549, 40, 'not_found', 'Property Address #3', '', '', 0),
(550, 40, 'conflict', 'Home Builder address', '22,23', '', 0),
(551, 40, 'conflict', 'Home Builder Telephone', '22,24', '', 0),
(552, 40, 'conflict', 'Home Builder Website', '22,25', '', 0),
(553, 40, 'conflict', 'Miscellaneous #2', '37,38', '', 0),
(554, 40, 'not_found', 'Warranty', '', '', 0),
(555, 40, 'conflict', 'Mineral Rights Deed\\Leases', '53,54', '', 0),
(556, 40, 'conflict', 'Miscellaneous Activity Field #1', '37,55', '', 0),
(557, 40, 'conflict', 'Miscellaneous Activity Field #2', '37,55', '', 0),
(558, 40, 'conflict', 'Miscellaneous Activity Field #3', '37,55', '', 0),
(559, 40, 'conflict', 'Miscellaneous Activity Field #4', '37,55', '', 0),
(560, 40, 'conflict', 'Miscellaneous Activity Field #5', '37,55', '', 0),
(561, 40, 'not_found', 'Contractor', '', '', 0),
(562, 40, 'not_found', 'Contractor address', '', '', 0),
(563, 40, 'not_found', 'Contractor phone number', '', '', 0),
(564, 40, 'not_found', 'Quantity', '', '', 0),
(565, 40, 'not_found', 'Door Manufacturer', '', '', 0),
(566, 40, 'not_found', 'Door Model Number', '', '', 0),
(567, 40, 'not_found', 'Date installed', '', '', 0),
(568, 40, 'not_found', 'System Manufacturer', '', '', 0),
(569, 40, 'not_found', 'System Model Number', '', '', 0),
(570, 40, 'not_found', 'Alarm System', '', '', 0),
(571, 40, 'not_found', 'Foundation', '', '', 0),
(572, 40, 'not_found', 'Type', '', '', 0),
(573, 40, 'not_found', 'Windows', '', '', 0),
(574, 40, 'not_found', 'Manufacturer', '', '', 0),
(575, 40, 'not_found', 'Manufacturer address', '', '', 0),
(576, 40, 'not_found', 'Manufacturer phone number', '', '', 0),
(577, 40, 'not_found', 'Manufacturer website', '', '', 0),
(578, 40, 'not_found', 'Model', '', '', 0),
(579, 40, 'not_found', 'HVAC', '', '', 0),
(580, 40, 'not_found', 'Furnace Manufacturer', '', '', 0),
(581, 40, 'not_found', 'Furnace Model Numbers', '', '', 0),
(582, 40, 'not_found', 'Condenser Manufacturer', '', '', 0),
(583, 40, 'not_found', 'Condenser Model Number', '', '', 0),
(584, 40, 'not_found', 'Date Installed', '', '', 0),
(585, 40, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(586, 40, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(587, 40, 'not_found', 'Emergency Generator', '', '', 0),
(588, 40, 'not_found', 'Model Numbers', '', '', 0),
(589, 40, 'not_found', 'Septic System', '', '', 0),
(590, 40, 'not_found', 'Water Well System', '', '', 0),
(591, 40, 'not_found', 'Irrigation System', '', '', 0),
(592, 40, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(593, 40, 'not_found', 'Sauna', '', '', 0),
(594, 40, 'not_found', 'Plumbing Contractor', '', '', 0),
(595, 40, 'not_found', 'Finish', '', '', 0),
(596, 40, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(597, 40, 'not_found', 'Appliances', '', '', 0),
(598, 40, 'not_found', 'Painting', '', '', 0),
(599, 40, 'not_found', 'Date work done', '', '', 0),
(600, 40, 'not_found', 'Walls', '', '', 0),
(601, 40, 'not_found', 'Brand', '', '', 0),
(602, 40, 'not_found', 'Color', '', '', 0),
(603, 40, 'not_found', 'Ceilings', '', '', 0),
(604, 40, 'not_found', 'Doors and Trim', '', '', 0),
(605, 40, 'not_found', 'Closet', '', '', 0),
(606, 40, 'not_found', 'Bathrooms', '', '', 0),
(607, 40, 'not_found', 'Cabinets', '', '', 0),
(608, 40, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(609, 40, 'not_found', 'Exterior Trim', '', '', 0),
(610, 40, 'not_found', 'Exterior Front Door', '', '', 0),
(611, 40, 'not_found', 'Exterior Walls', '', '', 0),
(612, 40, 'not_found', 'Brick manufacturer', '', '', 0),
(613, 40, 'not_found', 'Siding', '', '', 0),
(614, 40, 'not_found', 'Stone', '', '', 0),
(615, 40, 'not_found', 'Kitchen Cabinets', '', '', 0),
(616, 40, 'not_found', 'Finish Type', '', '', 0),
(617, 40, 'not_found', 'Kitchen Countertop', '', '', 0),
(618, 40, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(619, 40, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(620, 40, 'not_found', 'Powder Room Countertop', '', '', 0),
(621, 40, 'not_found', 'Powder Room Cabinets', '', '', 0),
(622, 40, 'not_found', 'Bath #2 Countertop', '', '', 0),
(623, 40, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(624, 40, 'not_found', 'Fireplace #1', '', '', 0),
(625, 40, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(626, 40, 'not_found', 'Surround Type', '', '', 0),
(627, 40, 'not_found', 'Surround Finish', '', '', 0),
(628, 40, 'not_found', 'Surround Color', '', '', 0),
(629, 40, 'not_found', 'Surround Brand', '', '', 0),
(630, 40, 'not_found', 'Surround Manufacturer', '', '', 0),
(631, 40, 'not_found', 'Hearth Type', '', '', 0),
(632, 40, 'not_found', 'Hearth Finish', '', '', 0),
(633, 40, 'not_found', 'Hearth Color', '', '', 0),
(634, 40, 'not_found', 'Hearth Brand', '', '', 0),
(635, 40, 'not_found', 'Hearth Manufacturer', '', '', 0),
(636, 40, 'not_found', 'Living Room', '', '', 0),
(637, 40, 'not_found', 'Flooring Type', '', '', 0),
(638, 40, 'not_found', 'Wall Paint', '', '', 0),
(639, 40, 'not_found', 'Accent Wall Paint', '', '', 0),
(640, 40, 'not_found', 'Ceiling Paint', '', '', 0),
(641, 40, 'not_found', 'Doors and Trim Paint', '', '', 0),
(642, 40, 'not_found', 'Kitchen', '', '', 0),
(643, 40, 'not_found', 'Family Room', '', '', 0),
(644, 40, 'not_found', 'Dining Room', '', '', 0),
(645, 40, 'not_found', 'Breakfast Room', '', '', 0),
(646, 40, 'not_found', 'Game Room', '', '', 0),
(647, 40, 'not_found', 'Master Bedroom', '', '', 0),
(648, 40, 'not_found', 'Bedroom #2', '', '', 0),
(649, 40, 'not_found', 'Bedroom #3', '', '', 0),
(650, 40, 'not_found', 'Bedroom #4', '', '', 0),
(651, 40, 'not_found', 'Utility Room', '', '', 0),
(652, 40, 'not_found', 'Master Bathroom', '', '', 0),
(653, 40, 'not_found', 'Wall Tile', '', '', 0),
(654, 40, 'not_found', '2nd Bathroom', '', '', 0),
(655, 40, 'not_found', 'Powder Room', '', '', 0),
(656, 41, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(657, 41, 'not_found', 'Property Address #2', '', '', 0),
(658, 41, 'not_found', 'Property Address #3', '', '', 0),
(659, 41, 'conflict', 'Home Builder address', '22,23', '', 0),
(660, 41, 'conflict', 'Home Builder Telephone', '22,24', '', 0),
(661, 41, 'conflict', 'Home Builder Website', '22,25', '', 0),
(662, 41, 'conflict', 'Miscellaneous #2', '37,38', '', 0),
(663, 41, 'not_found', 'Warranty', '', '', 0),
(664, 41, 'conflict', 'Mineral Rights Deed\\Leases', '53,54', '', 0),
(665, 41, 'conflict', 'Miscellaneous Activity Field #1', '37,55', '', 0),
(666, 41, 'conflict', 'Miscellaneous Activity Field #2', '37,55', '', 0),
(667, 41, 'conflict', 'Miscellaneous Activity Field #3', '37,55', '', 0),
(668, 41, 'conflict', 'Miscellaneous Activity Field #4', '37,55', '', 0),
(669, 41, 'conflict', 'Miscellaneous Activity Field #5', '37,55', '', 0),
(670, 41, 'not_found', 'Contractor', '', '', 0),
(671, 41, 'not_found', 'Contractor address', '', '', 0),
(672, 41, 'not_found', 'Contractor phone number', '', '', 0),
(673, 41, 'not_found', 'Quantity', '', '', 0),
(674, 41, 'not_found', 'Door Manufacturer', '', '', 0),
(675, 41, 'not_found', 'Door Model Number', '', '', 0),
(676, 41, 'not_found', 'Date installed', '', '', 0),
(677, 41, 'not_found', 'System Manufacturer', '', '', 0),
(678, 41, 'not_found', 'System Model Number', '', '', 0),
(679, 41, 'not_found', 'Alarm System', '', '', 0),
(680, 41, 'not_found', 'Foundation', '', '', 0),
(681, 41, 'not_found', 'Type', '', '', 0),
(682, 41, 'not_found', 'Windows', '', '', 0),
(683, 41, 'not_found', 'Manufacturer', '', '', 0),
(684, 41, 'not_found', 'Manufacturer address', '', '', 0),
(685, 41, 'not_found', 'Manufacturer phone number', '', '', 0),
(686, 41, 'not_found', 'Manufacturer website', '', '', 0),
(687, 41, 'not_found', 'Model', '', '', 0),
(688, 41, 'not_found', 'HVAC', '', '', 0),
(689, 41, 'not_found', 'Furnace Manufacturer', '', '', 0),
(690, 41, 'not_found', 'Furnace Model Numbers', '', '', 0),
(691, 41, 'not_found', 'Condenser Manufacturer', '', '', 0),
(692, 41, 'not_found', 'Condenser Model Number', '', '', 0),
(693, 41, 'not_found', 'Date Installed', '', '', 0),
(694, 41, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(695, 41, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(696, 41, 'not_found', 'Emergency Generator', '', '', 0),
(697, 41, 'not_found', 'Model Numbers', '', '', 0),
(698, 41, 'not_found', 'Septic System', '', '', 0),
(699, 41, 'not_found', 'Water Well System', '', '', 0),
(700, 41, 'not_found', 'Irrigation System', '', '', 0),
(701, 41, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(702, 41, 'not_found', 'Sauna', '', '', 0),
(703, 41, 'not_found', 'Plumbing Contractor', '', '', 0),
(704, 41, 'not_found', 'Finish', '', '', 0),
(705, 41, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(706, 41, 'not_found', 'Appliances', '', '', 0),
(707, 41, 'not_found', 'Painting', '', '', 0),
(708, 41, 'not_found', 'Date work done', '', '', 0),
(709, 41, 'not_found', 'Walls', '', '', 0),
(710, 41, 'not_found', 'Brand', '', '', 0),
(711, 41, 'not_found', 'Color', '', '', 0),
(712, 41, 'not_found', 'Ceilings', '', '', 0),
(713, 41, 'not_found', 'Doors and Trim', '', '', 0),
(714, 41, 'not_found', 'Closet', '', '', 0),
(715, 41, 'not_found', 'Bathrooms', '', '', 0),
(716, 41, 'not_found', 'Cabinets', '', '', 0),
(717, 41, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(718, 41, 'not_found', 'Exterior Trim', '', '', 0),
(719, 41, 'not_found', 'Exterior Front Door', '', '', 0),
(720, 41, 'not_found', 'Exterior Walls', '', '', 0),
(721, 41, 'not_found', 'Brick manufacturer', '', '', 0),
(722, 41, 'not_found', 'Siding', '', '', 0),
(723, 41, 'not_found', 'Stone', '', '', 0),
(724, 41, 'not_found', 'Kitchen Cabinets', '', '', 0),
(725, 41, 'not_found', 'Finish Type', '', '', 0),
(726, 41, 'not_found', 'Kitchen Countertop', '', '', 0),
(727, 41, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(728, 41, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(729, 41, 'not_found', 'Powder Room Countertop', '', '', 0),
(730, 41, 'not_found', 'Powder Room Cabinets', '', '', 0),
(731, 41, 'not_found', 'Bath #2 Countertop', '', '', 0),
(732, 41, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(733, 41, 'not_found', 'Fireplace #1', '', '', 0),
(734, 41, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(735, 41, 'not_found', 'Surround Type', '', '', 0),
(736, 41, 'not_found', 'Surround Finish', '', '', 0),
(737, 41, 'not_found', 'Surround Color', '', '', 0),
(738, 41, 'not_found', 'Surround Brand', '', '', 0),
(739, 41, 'not_found', 'Surround Manufacturer', '', '', 0),
(740, 41, 'not_found', 'Hearth Type', '', '', 0),
(741, 41, 'not_found', 'Hearth Finish', '', '', 0),
(742, 41, 'not_found', 'Hearth Color', '', '', 0),
(743, 41, 'not_found', 'Hearth Brand', '', '', 0),
(744, 41, 'not_found', 'Hearth Manufacturer', '', '', 0),
(745, 41, 'not_found', 'Living Room', '', '', 0),
(746, 41, 'not_found', 'Flooring Type', '', '', 0),
(747, 41, 'not_found', 'Wall Paint', '', '', 0),
(748, 41, 'not_found', 'Accent Wall Paint', '', '', 0),
(749, 41, 'not_found', 'Ceiling Paint', '', '', 0),
(750, 41, 'not_found', 'Doors and Trim Paint', '', '', 0),
(751, 41, 'not_found', 'Kitchen', '', '', 0),
(752, 41, 'not_found', 'Family Room', '', '', 0),
(753, 41, 'not_found', 'Dining Room', '', '', 0),
(754, 41, 'not_found', 'Breakfast Room', '', '', 0),
(755, 41, 'not_found', 'Game Room', '', '', 0),
(756, 41, 'not_found', 'Master Bedroom', '', '', 0),
(757, 41, 'not_found', 'Bedroom #2', '', '', 0),
(758, 41, 'not_found', 'Bedroom #3', '', '', 0),
(759, 41, 'not_found', 'Bedroom #4', '', '', 0),
(760, 41, 'not_found', 'Utility Room', '', '', 0),
(761, 41, 'not_found', 'Master Bathroom', '', '', 0),
(762, 41, 'not_found', 'Wall Tile', '', '', 0),
(763, 41, 'not_found', '2nd Bathroom', '', '', 0),
(764, 41, 'not_found', 'Powder Room', '', '', 0),
(765, 42, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(766, 42, 'not_found', 'Property Address #2', '', '', 0),
(767, 42, 'not_found', 'Property Address #3', '', '', 0),
(768, 42, 'conflict', 'Home Builder address', '22,23', '', 0),
(769, 42, 'conflict', 'Home Builder Telephone', '22,24', '', 0),
(770, 42, 'conflict', 'Home Builder Website', '22,25', '', 0),
(771, 42, 'conflict', 'Miscellaneous #2', '37,38', '', 0),
(772, 42, 'not_found', 'Warranty', '', '', 0),
(773, 42, 'conflict', 'Mineral Rights Deed\\Leases', '53,54', '', 0),
(774, 42, 'conflict', 'Miscellaneous Activity Field #1', '37,55', '', 0),
(775, 42, 'conflict', 'Miscellaneous Activity Field #2', '37,55', '', 0),
(776, 42, 'conflict', 'Miscellaneous Activity Field #3', '37,55', '', 0),
(777, 42, 'conflict', 'Miscellaneous Activity Field #4', '37,55', '', 0),
(778, 42, 'conflict', 'Miscellaneous Activity Field #5', '37,55', '', 0),
(779, 42, 'not_found', 'Contractor', '', '', 0),
(780, 42, 'not_found', 'Contractor address', '', '', 0),
(781, 42, 'not_found', 'Contractor phone number', '', '', 0),
(782, 42, 'not_found', 'Quantity', '', '', 0),
(783, 42, 'not_found', 'Door Manufacturer', '', '', 0),
(784, 42, 'not_found', 'Door Model Number', '', '', 0),
(785, 42, 'not_found', 'Date installed', '', '', 0),
(786, 42, 'not_found', 'System Manufacturer', '', '', 0),
(787, 42, 'not_found', 'System Model Number', '', '', 0),
(788, 42, 'not_found', 'Alarm System', '', '', 0),
(789, 42, 'not_found', 'Foundation', '', '', 0),
(790, 42, 'not_found', 'Type', '', '', 0),
(791, 42, 'not_found', 'Windows', '', '', 0),
(792, 42, 'not_found', 'Manufacturer', '', '', 0),
(793, 42, 'not_found', 'Manufacturer address', '', '', 0),
(794, 42, 'not_found', 'Manufacturer phone number', '', '', 0),
(795, 42, 'not_found', 'Manufacturer website', '', '', 0),
(796, 42, 'not_found', 'Model', '', '', 0),
(797, 42, 'not_found', 'HVAC', '', '', 0),
(798, 42, 'not_found', 'Furnace Manufacturer', '', '', 0),
(799, 42, 'not_found', 'Furnace Model Numbers', '', '', 0),
(800, 42, 'not_found', 'Condenser Manufacturer', '', '', 0),
(801, 42, 'not_found', 'Condenser Model Number', '', '', 0),
(802, 42, 'not_found', 'Date Installed', '', '', 0),
(803, 42, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(804, 42, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(805, 42, 'not_found', 'Emergency Generator', '', '', 0),
(806, 42, 'not_found', 'Model Numbers', '', '', 0),
(807, 42, 'not_found', 'Septic System', '', '', 0),
(808, 42, 'not_found', 'Water Well System', '', '', 0),
(809, 42, 'not_found', 'Irrigation System', '', '', 0),
(810, 42, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(811, 42, 'not_found', 'Sauna', '', '', 0),
(812, 42, 'not_found', 'Plumbing Contractor', '', '', 0),
(813, 42, 'not_found', 'Finish', '', '', 0),
(814, 42, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(815, 42, 'not_found', 'Appliances', '', '', 0),
(816, 42, 'not_found', 'Painting', '', '', 0),
(817, 42, 'not_found', 'Date work done', '', '', 0),
(818, 42, 'not_found', 'Walls', '', '', 0),
(819, 42, 'not_found', 'Brand', '', '', 0),
(820, 42, 'not_found', 'Color', '', '', 0),
(821, 42, 'not_found', 'Ceilings', '', '', 0),
(822, 42, 'not_found', 'Doors and Trim', '', '', 0),
(823, 42, 'not_found', 'Closet', '', '', 0),
(824, 42, 'not_found', 'Bathrooms', '', '', 0),
(825, 42, 'not_found', 'Cabinets', '', '', 0),
(826, 42, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(827, 42, 'not_found', 'Exterior Trim', '', '', 0),
(828, 42, 'not_found', 'Exterior Front Door', '', '', 0),
(829, 42, 'not_found', 'Exterior Walls', '', '', 0),
(830, 42, 'not_found', 'Brick manufacturer', '', '', 0),
(831, 42, 'not_found', 'Siding', '', '', 0),
(832, 42, 'not_found', 'Stone', '', '', 0),
(833, 42, 'not_found', 'Kitchen Cabinets', '', '', 0),
(834, 42, 'not_found', 'Finish Type', '', '', 0),
(835, 42, 'not_found', 'Kitchen Countertop', '', '', 0),
(836, 42, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(837, 42, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(838, 42, 'not_found', 'Powder Room Countertop', '', '', 0),
(839, 42, 'not_found', 'Powder Room Cabinets', '', '', 0),
(840, 42, 'not_found', 'Bath #2 Countertop', '', '', 0),
(841, 42, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(842, 42, 'not_found', 'Fireplace #1', '', '', 0),
(843, 42, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(844, 42, 'not_found', 'Surround Type', '', '', 0),
(845, 42, 'not_found', 'Surround Finish', '', '', 0),
(846, 42, 'not_found', 'Surround Color', '', '', 0),
(847, 42, 'not_found', 'Surround Brand', '', '', 0),
(848, 42, 'not_found', 'Surround Manufacturer', '', '', 0),
(849, 42, 'not_found', 'Hearth Type', '', '', 0),
(850, 42, 'not_found', 'Hearth Finish', '', '', 0),
(851, 42, 'not_found', 'Hearth Color', '', '', 0),
(852, 42, 'not_found', 'Hearth Brand', '', '', 0),
(853, 42, 'not_found', 'Hearth Manufacturer', '', '', 0),
(854, 42, 'not_found', 'Living Room', '', '', 0),
(855, 42, 'not_found', 'Flooring Type', '', '', 0),
(856, 42, 'not_found', 'Wall Paint', '', '', 0),
(857, 42, 'not_found', 'Accent Wall Paint', '', '', 0),
(858, 42, 'not_found', 'Ceiling Paint', '', '', 0),
(859, 42, 'not_found', 'Doors and Trim Paint', '', '', 0),
(860, 42, 'not_found', 'Kitchen', '', '', 0),
(861, 42, 'not_found', 'Family Room', '', '', 0),
(862, 42, 'not_found', 'Dining Room', '', '', 0),
(863, 42, 'not_found', 'Breakfast Room', '', '', 0),
(864, 42, 'not_found', 'Game Room', '', '', 0),
(865, 42, 'not_found', 'Master Bedroom', '', '', 0),
(866, 42, 'not_found', 'Bedroom #2', '', '', 0),
(867, 42, 'not_found', 'Bedroom #3', '', '', 0),
(868, 42, 'not_found', 'Bedroom #4', '', '', 0),
(869, 42, 'not_found', 'Utility Room', '', '', 0),
(870, 42, 'not_found', 'Master Bathroom', '', '', 0),
(871, 42, 'not_found', 'Wall Tile', '', '', 0),
(872, 42, 'not_found', '2nd Bathroom', '', '', 0),
(873, 42, 'not_found', 'Powder Room', '', '', 0),
(874, 43, 'not_found', 'Number Identifier - Flexible', '', '', 0),
(875, 43, 'not_found', 'Property Address #2', '', '', 0),
(876, 43, 'not_found', 'Property Address #3', '', '', 0),
(877, 43, 'conflict', 'Home Builder address', '22,23', '', 0),
(878, 43, 'conflict', 'Home Builder Telephone', '22,24', '', 0),
(879, 43, 'conflict', 'Home Builder Website', '22,25', '', 0),
(880, 43, 'conflict', 'Miscellaneous #2', '37,38', '', 0),
(881, 43, 'not_found', 'Warranty', '', '', 0),
(882, 43, 'conflict', 'Mineral Rights Deed\\Leases', '53,54', '', 0),
(883, 43, 'conflict', 'Miscellaneous Activity Field #1', '37,55', '', 0),
(884, 43, 'conflict', 'Miscellaneous Activity Field #2', '37,55', '', 0),
(885, 43, 'conflict', 'Miscellaneous Activity Field #3', '37,55', '', 0),
(886, 43, 'conflict', 'Miscellaneous Activity Field #4', '37,55', '', 0),
(887, 43, 'conflict', 'Miscellaneous Activity Field #5', '37,55', '', 0),
(888, 43, 'not_found', 'Contractor', '', '', 0),
(889, 43, 'not_found', 'Contractor address', '', '', 0),
(890, 43, 'not_found', 'Contractor phone number', '', '', 0),
(891, 43, 'not_found', 'Quantity', '', '', 0),
(892, 43, 'not_found', 'Door Manufacturer', '', '', 0),
(893, 43, 'not_found', 'Door Model Number', '', '', 0),
(894, 43, 'not_found', 'Date installed', '', '', 0),
(895, 43, 'not_found', 'System Manufacturer', '', '', 0),
(896, 43, 'not_found', 'System Model Number', '', '', 0),
(897, 43, 'not_found', 'Alarm System', '', '', 0),
(898, 43, 'not_found', 'Foundation', '', '', 0),
(899, 43, 'not_found', 'Type', '', '', 0),
(900, 43, 'not_found', 'Windows', '', '', 0),
(901, 43, 'not_found', 'Manufacturer', '', '', 0),
(902, 43, 'not_found', 'Manufacturer address', '', '', 0),
(903, 43, 'not_found', 'Manufacturer phone number', '', '', 0),
(904, 43, 'not_found', 'Manufacturer website', '', '', 0),
(905, 43, 'not_found', 'Model', '', '', 0),
(906, 43, 'not_found', 'HVAC', '', '', 0),
(907, 43, 'not_found', 'Furnace Manufacturer', '', '', 0),
(908, 43, 'not_found', 'Furnace Model Numbers', '', '', 0),
(909, 43, 'not_found', 'Condenser Manufacturer', '', '', 0),
(910, 43, 'not_found', 'Condenser Model Number', '', '', 0),
(911, 43, 'not_found', 'Date Installed', '', '', 0),
(912, 43, 'not_found', 'Evaporator Coil Manufacturer', '', '', 0),
(913, 43, 'not_found', 'Evaporator Coil Model Number', '', '', 0),
(914, 43, 'not_found', 'Emergency Generator', '', '', 0),
(915, 43, 'not_found', 'Model Numbers', '', '', 0),
(916, 43, 'not_found', 'Septic System', '', '', 0),
(917, 43, 'not_found', 'Water Well System', '', '', 0),
(918, 43, 'not_found', 'Irrigation System', '', '', 0),
(919, 43, 'not_found', 'Spa\\Hot Tub', '', '', 0),
(920, 43, 'not_found', 'Sauna', '', '', 0),
(921, 43, 'not_found', 'Plumbing Contractor', '', '', 0),
(922, 43, 'not_found', 'Finish', '', '', 0),
(923, 43, 'not_found', 'Faucet Brand \\ Manufacturer', '', '', 0),
(924, 43, 'not_found', 'Appliances', '', '', 0),
(925, 43, 'not_found', 'Painting', '', '', 0),
(926, 43, 'not_found', 'Date work done', '', '', 0),
(927, 43, 'not_found', 'Walls', '', '', 0),
(928, 43, 'not_found', 'Brand', '', '', 0),
(929, 43, 'not_found', 'Color', '', '', 0),
(930, 43, 'not_found', 'Ceilings', '', '', 0),
(931, 43, 'not_found', 'Doors and Trim', '', '', 0),
(932, 43, 'not_found', 'Closet', '', '', 0),
(933, 43, 'not_found', 'Bathrooms', '', '', 0),
(934, 43, 'not_found', 'Cabinets', '', '', 0),
(935, 43, 'not_found', 'Staircase and wood Trim Stain', '', '', 0),
(936, 43, 'not_found', 'Exterior Trim', '', '', 0),
(937, 43, 'not_found', 'Exterior Front Door', '', '', 0),
(938, 43, 'not_found', 'Exterior Walls', '', '', 0),
(939, 43, 'not_found', 'Brick manufacturer', '', '', 0),
(940, 43, 'not_found', 'Siding', '', '', 0),
(941, 43, 'not_found', 'Stone', '', '', 0),
(942, 43, 'not_found', 'Kitchen Cabinets', '', '', 0),
(943, 43, 'not_found', 'Finish Type', '', '', 0),
(944, 43, 'not_found', 'Kitchen Countertop', '', '', 0),
(945, 43, 'not_found', 'Master Bathroom Vanity Top', '', '', 0),
(946, 43, 'not_found', 'Master Bathroom Vanity Cabinets', '', '', 0),
(947, 43, 'not_found', 'Powder Room Countertop', '', '', 0);
INSERT INTO `wx_template_errors` (`id`, `wx_batch_id`, `type_error`, `dbf_key`, `message`, `notes`, `is_hidden`) VALUES
(948, 43, 'not_found', 'Powder Room Cabinets', '', '', 0),
(949, 43, 'not_found', 'Bath #2 Countertop', '', '', 0),
(950, 43, 'not_found', 'Bath # 2 Cabinets', '', '', 0),
(951, 43, 'not_found', 'Fireplace #1', '', '', 0),
(952, 43, 'not_found', 'Fireplace #1 - Mantel & Surround', '', '', 0),
(953, 43, 'not_found', 'Surround Type', '', '', 0),
(954, 43, 'not_found', 'Surround Finish', '', '', 0),
(955, 43, 'not_found', 'Surround Color', '', '', 0),
(956, 43, 'not_found', 'Surround Brand', '', '', 0),
(957, 43, 'not_found', 'Surround Manufacturer', '', '', 0),
(958, 43, 'not_found', 'Hearth Type', '', '', 0),
(959, 43, 'not_found', 'Hearth Finish', '', '', 0),
(960, 43, 'not_found', 'Hearth Color', '', '', 0),
(961, 43, 'not_found', 'Hearth Brand', '', '', 0),
(962, 43, 'not_found', 'Hearth Manufacturer', '', '', 0),
(963, 43, 'not_found', 'Living Room', '', '', 0),
(964, 43, 'not_found', 'Flooring Type', '', '', 0),
(965, 43, 'not_found', 'Wall Paint', '', '', 0),
(966, 43, 'not_found', 'Accent Wall Paint', '', '', 0),
(967, 43, 'not_found', 'Ceiling Paint', '', '', 0),
(968, 43, 'not_found', 'Doors and Trim Paint', '', '', 0),
(969, 43, 'not_found', 'Kitchen', '', '', 0),
(970, 43, 'not_found', 'Family Room', '', '', 0),
(971, 43, 'not_found', 'Dining Room', '', '', 0),
(972, 43, 'not_found', 'Breakfast Room', '', '', 0),
(973, 43, 'not_found', 'Game Room', '', '', 0),
(974, 43, 'not_found', 'Master Bedroom', '', '', 0),
(975, 43, 'not_found', 'Bedroom #2', '', '', 0),
(976, 43, 'not_found', 'Bedroom #3', '', '', 0),
(977, 43, 'not_found', 'Bedroom #4', '', '', 0),
(978, 43, 'not_found', 'Utility Room', '', '', 0),
(979, 43, 'not_found', 'Master Bathroom', '', '', 0),
(980, 43, 'not_found', 'Wall Tile', '', '', 0),
(981, 43, 'not_found', '2nd Bathroom', '', '', 0),
(982, 43, 'not_found', 'Powder Room', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wx_template_flags`
--

CREATE TABLE IF NOT EXISTS `wx_template_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `priority` int(11) NOT NULL,
  `db_hint_for_needed` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `date_created` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `wx_template_flags`
--

INSERT INTO `wx_template_flags` (`id`, `name`, `priority`, `db_hint_for_needed`, `notes`, `date_created`) VALUES
(1, 'Main', 0, 'propertyMainTable', 'This is the first part of the form where most of the data is expected to goto the main table', '2016-10-07'),
(2, 'Parking', 1, 'parkingTable', 'This is for the parking subfields', '2016-10-07');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `app_settings`
--
ALTER TABLE `app_settings`
  ADD CONSTRAINT `app_settings_ibfk_1` FOREIGN KEY (`wx_template_id`) REFERENCES `wx_templates` (`id`);

--
-- Constraints for table `contractor`
--
ALTER TABLE `contractor`
  ADD CONSTRAINT `fk_Contractor_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `homebuilder`
--
ALTER TABLE `homebuilder`
  ADD CONSTRAINT `fk_HomeBuilder_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `parking`
--
ALTER TABLE `parking`
  ADD CONSTRAINT `fk_Parking_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Parking_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pricecomparison`
--
ALTER TABLE `pricecomparison`
  ADD CONSTRAINT `fk_PriceComparison_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyactivity`
--
ALTER TABLE `propertyactivity`
  ADD CONSTRAINT `fk_PropertyActivity_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyActivity_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyconstruction`
--
ALTER TABLE `propertyconstruction`
  ADD CONSTRAINT `fk_PropertyConstruction_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyConstruction_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertydeed`
--
ALTER TABLE `propertydeed`
  ADD CONSTRAINT `fk_PropertyDeed_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyDeed_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertydocuments`
--
ALTER TABLE `propertydocuments`
  ADD CONSTRAINT `fk_PropertyDocuments_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyDocuments_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertygf`
--
ALTER TABLE `propertygf`
  ADD CONSTRAINT `fk_PropertyGF_PropertyMain` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyGF_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyitem`
--
ALTER TABLE `propertyitem`
  ADD CONSTRAINT `fk_PropertyItem_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyiteminstallation`
--
ALTER TABLE `propertyiteminstallation`
  ADD CONSTRAINT `fk_PropertyItemInstallation_Contractor1` FOREIGN KEY (`PropertyContractorId`) REFERENCES `contractor` (`ContractorId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_PropertyConstruction1` FOREIGN KEY (`PropertyConstructionId`) REFERENCES `propertyconstruction` (`PropertyConstructionId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertyiteminstallation_has_propertyitem`
--
ALTER TABLE `propertyiteminstallation_has_propertyitem`
  ADD CONSTRAINT `fk_PropertyItemInstallation_has_PropertyItem_PropertyItem1` FOREIGN KEY (`PropertyItem_PropertyItemId`) REFERENCES `propertyitem` (`PropertyItemId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyItemInstallation_has_PropertyItem_PropertyItemInst1` FOREIGN KEY (`PropertyItemInstallation_PropertyItemInstallationId`) REFERENCES `propertyiteminstallation` (`PropertyItemInstallationId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertymain`
--
ALTER TABLE `propertymain`
  ADD CONSTRAINT `fk_PropertyMain_HomeBuilder1` FOREIGN KEY (`PropertyBuilderId`) REFERENCES `homebuilder` (`HomeBuilderId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyMain_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertypaint`
--
ALTER TABLE `propertypaint`
  ADD CONSTRAINT `fk_PropertyPaint_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_PropertyPaint_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `propertypermit`
--
ALTER TABLE `propertypermit`
  ADD CONSTRAINT `fk_PropertyPermit_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `storage`
--
ALTER TABLE `storage`
  ADD CONSTRAINT `fk_Storage_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Storage_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `swimmingpool`
--
ALTER TABLE `swimmingpool`
  ADD CONSTRAINT `fk_SwimmingPool_PropertyMain1` FOREIGN KEY (`PropertyId`) REFERENCES `propertymain` (`PropertyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_SwimmingPool_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `uscity`
--
ALTER TABLE `uscity`
  ADD CONSTRAINT `fk_USCity_USCounty1` FOREIGN KEY (`CountyId`) REFERENCES `uscounty` (`USCountyId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_USCity_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `uscounty`
--
ALTER TABLE `uscounty`
  ADD CONSTRAINT `fk_USCounty_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_USCounty_UState1` FOREIGN KEY (`StateId`) REFERENCES `ustate` (`UStateId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ustate`
--
ALTER TABLE `ustate`
  ADD CONSTRAINT `fk_UState_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `fk_WishList_Users1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `wx_batch`
--
ALTER TABLE `wx_batch`
  ADD CONSTRAINT `wx_batch_ibfk_1` FOREIGN KEY (`app_user_id`) REFERENCES `app_users` (`id`),
  ADD CONSTRAINT `wx_batch_ibfk_2` FOREIGN KEY (`wx_template_id`) REFERENCES `wx_templates` (`id`);

--
-- Constraints for table `wx_batch_updates`
--
ALTER TABLE `wx_batch_updates`
  ADD CONSTRAINT `wx_batch_updates_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `wx_batch` (`id`);

--
-- Constraints for table `wx_template_columns`
--
ALTER TABLE `wx_template_columns`
  ADD CONSTRAINT `wx_template_columns_ibfk_1` FOREIGN KEY (`wx_template_id`) REFERENCES `wx_templates` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_2` FOREIGN KEY (`flag_needed_a`) REFERENCES `wx_template_flags` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_3` FOREIGN KEY (`flag_needed_b`) REFERENCES `wx_template_flags` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_4` FOREIGN KEY (`app_user_id`) REFERENCES `app_users` (`id`),
  ADD CONSTRAINT `wx_template_columns_ibfk_5` FOREIGN KEY (`flag_to_raise`) REFERENCES `wx_template_flags` (`id`);

--
-- Constraints for table `wx_template_errors`
--
ALTER TABLE `wx_template_errors`
  ADD CONSTRAINT `wx_template_errors_ibfk_1` FOREIGN KEY (`wx_batch_id`) REFERENCES `wx_batch` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
